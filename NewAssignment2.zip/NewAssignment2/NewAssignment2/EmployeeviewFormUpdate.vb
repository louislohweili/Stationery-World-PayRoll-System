﻿Public Class EmployeeviewFormUpdate
    Private intRowPosition As Integer = 0

    Private Sub EmployeeviewFormUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BranchDS.Branch' table. You can move, or remove it, as needed.
        Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
        'TODO: This line of code loads data into the 'BranchDS.Branch' table. You can move, or remove it, as needed.
        Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
        'TODO: This line of code loads data into the 'EmployeeDS.Employee' table. You can move, or remove it, as needed.
        Me.EmployeeTableAdapter.Fill(Me.EmployeeDS.Employee)
        txtStaffID.Text = ""
        txtName.Text = ""
        txtDOB.Text = ""
        txtGender.Text = ""
        txtEmail.Text = ""
        txtHireDate.Text = ""
        txtCvar.Text = ""
        txtBranch.Text = ""
        txtBranchNo.Text = ""
        txtSalary.Text = ""
        intRowPosition = EmployeeDS.Tables("Employee").Rows.Count
    End Sub
    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            txtStaffID.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Staff_ID").ToString()
            txtName.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Name").ToString()
            txtDOB.Text = Format(EmployeeDS.Tables("Employee").Rows(intRowPosition)("DOB"), "dd-mm-yyyy")
            txtGender.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Gender").ToString()
            txtEmail.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Email").ToString()
            txtDOB.Text = Format(EmployeeDS.Tables("Employee").Rows(intRowPosition)("DOB"), "dd-mm-yyyy")
            txtHireDate.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Hire_date").ToString()
            txtCvar.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Cvar").ToString()
            txtBranch.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Branch").ToString()
            txtBranchNo.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Branch_no").ToString()
            txtSalary.Text = FormatCurrency(EmployeeDS.Tables("Employee").Rows(intRowPosition)("Salary"), "$")
        End If
    End Sub

    Private Sub btmUpdateRecord_Click(sender As Object, e As EventArgs) Handles btmUpdateRecord.Click
        Dim newrow As DataRow = EmployeeDS.Tables("Employee").NewRow
        Try
            newrow("Staff_ID") = txtStaffID.Text
            newrow("Name") = txtName.Text
            newrow("DOB") = txtDOB.Text
            newrow("Gender") = txtGender.Text
            newrow("Email") = txtEmail.Text
            newrow("Hire_date") = txtHireDate.Text
            newrow("Cvar") = txtCvar.Text
            newrow("Branch") = txtBranch.Text
            newrow("Branch_no") = txtBranchNo.Text
            newrow("Salary") = txtSalary.Text

            EmployeeDS.Tables("Employee").Rows.Add(newrow)
            EmployeeTableAdapter.Update(Me.EmployeeDS.Employee)

            EmployeeDS.AcceptChanges()
            MessageBox.Show("Record Update")
            Me.EmployeeTableAdapter.Fill(Me.EmployeeDS.Employee)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub txtBranch_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnuploadphoto_Click(sender As Object, e As EventArgs) Handles btnuploadphoto.Click
        Frmuploadphoto1.ShowDialog()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtStaffID.Text = ""
        txtName.Text = ""
        txtDOB.Text = ""
        txtGender.Text = ""
        txtEmail.Text = ""
        txtHireDate.Text = ""
        txtCvar.Text = ""
        txtBranch.Text = ""
        txtBranchNo.Text = ""
        txtSalary.Text = ""
    End Sub
End Class