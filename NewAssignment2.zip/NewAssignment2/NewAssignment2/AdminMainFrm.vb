﻿Public Class AdminMainFrm
    Private Sub BtnBranchData_Click(sender As Object, e As EventArgs) Handles BtnBranchData.Click
        AdminEmployeeViewFrm.ShowDialog()
    End Sub

    Private Sub btnPayrollData_Click(sender As Object, e As EventArgs) Handles btnPayrollData.Click
        adminPayrollViewfrm.ShowDialog()

    End Sub

    Private Sub btnEmployeeData_Click(sender As Object, e As EventArgs) Handles btnEmployeeData.Click
        AdminEmployeeViewFrm.ShowDialog()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub AdminMainFrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class