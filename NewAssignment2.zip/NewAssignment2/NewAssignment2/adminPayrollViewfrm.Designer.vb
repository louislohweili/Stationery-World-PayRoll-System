﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class adminPayrollViewfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PayrollDS = New NewAssignment2.PayrollDS()
        Me.PayrollDSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PayrollBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PayrollTableAdapter = New NewAssignment2.PayrollDSTableAdapters.payrollTableAdapter()
        Me.StaffIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CvarDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BranchDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SalaryIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MonthlySalaryDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CommissionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DeductionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BankAccDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PayrollDS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PayrollDSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PayrollBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StaffIDDataGridViewTextBoxColumn, Me.NameDataGridViewTextBoxColumn, Me.CvarDataGridViewTextBoxColumn, Me.BranchDataGridViewTextBoxColumn, Me.SalaryIDDataGridViewTextBoxColumn, Me.MonthlySalaryDataGridViewTextBoxColumn, Me.CommissionDataGridViewTextBoxColumn, Me.DeductionDataGridViewTextBoxColumn, Me.BankAccDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.PayrollBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(951, 150)
        Me.DataGridView1.TabIndex = 0
        '
        'PayrollDS
        '
        Me.PayrollDS.DataSetName = "PayrollDS"
        Me.PayrollDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PayrollDSBindingSource
        '
        Me.PayrollDSBindingSource.DataSource = Me.PayrollDS
        Me.PayrollDSBindingSource.Position = 0
        '
        'PayrollBindingSource
        '
        Me.PayrollBindingSource.DataMember = "payroll"
        Me.PayrollBindingSource.DataSource = Me.PayrollDSBindingSource
        '
        'PayrollTableAdapter
        '
        Me.PayrollTableAdapter.ClearBeforeFill = True
        '
        'StaffIDDataGridViewTextBoxColumn
        '
        Me.StaffIDDataGridViewTextBoxColumn.DataPropertyName = "Staff_ID"
        Me.StaffIDDataGridViewTextBoxColumn.HeaderText = "Staff_ID"
        Me.StaffIDDataGridViewTextBoxColumn.Name = "StaffIDDataGridViewTextBoxColumn"
        '
        'NameDataGridViewTextBoxColumn
        '
        Me.NameDataGridViewTextBoxColumn.DataPropertyName = "Name"
        Me.NameDataGridViewTextBoxColumn.HeaderText = "Name"
        Me.NameDataGridViewTextBoxColumn.Name = "NameDataGridViewTextBoxColumn"
        '
        'CvarDataGridViewTextBoxColumn
        '
        Me.CvarDataGridViewTextBoxColumn.DataPropertyName = "Cvar"
        Me.CvarDataGridViewTextBoxColumn.HeaderText = "Cvar"
        Me.CvarDataGridViewTextBoxColumn.Name = "CvarDataGridViewTextBoxColumn"
        '
        'BranchDataGridViewTextBoxColumn
        '
        Me.BranchDataGridViewTextBoxColumn.DataPropertyName = "Branch"
        Me.BranchDataGridViewTextBoxColumn.HeaderText = "Branch"
        Me.BranchDataGridViewTextBoxColumn.Name = "BranchDataGridViewTextBoxColumn"
        '
        'SalaryIDDataGridViewTextBoxColumn
        '
        Me.SalaryIDDataGridViewTextBoxColumn.DataPropertyName = "Salary_ID"
        Me.SalaryIDDataGridViewTextBoxColumn.HeaderText = "Salary_ID"
        Me.SalaryIDDataGridViewTextBoxColumn.Name = "SalaryIDDataGridViewTextBoxColumn"
        '
        'MonthlySalaryDataGridViewTextBoxColumn
        '
        Me.MonthlySalaryDataGridViewTextBoxColumn.DataPropertyName = "monthly Salary"
        Me.MonthlySalaryDataGridViewTextBoxColumn.HeaderText = "monthly Salary"
        Me.MonthlySalaryDataGridViewTextBoxColumn.Name = "MonthlySalaryDataGridViewTextBoxColumn"
        '
        'CommissionDataGridViewTextBoxColumn
        '
        Me.CommissionDataGridViewTextBoxColumn.DataPropertyName = "commission"
        Me.CommissionDataGridViewTextBoxColumn.HeaderText = "commission"
        Me.CommissionDataGridViewTextBoxColumn.Name = "CommissionDataGridViewTextBoxColumn"
        '
        'DeductionDataGridViewTextBoxColumn
        '
        Me.DeductionDataGridViewTextBoxColumn.DataPropertyName = "deduction"
        Me.DeductionDataGridViewTextBoxColumn.HeaderText = "deduction"
        Me.DeductionDataGridViewTextBoxColumn.Name = "DeductionDataGridViewTextBoxColumn"
        '
        'BankAccDataGridViewTextBoxColumn
        '
        Me.BankAccDataGridViewTextBoxColumn.DataPropertyName = "Bank_Acc"
        Me.BankAccDataGridViewTextBoxColumn.HeaderText = "Bank_Acc"
        Me.BankAccDataGridViewTextBoxColumn.Name = "BankAccDataGridViewTextBoxColumn"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(808, 204)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(146, 35)
        Me.btnExit.TabIndex = 147
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'adminPayrollViewfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(970, 253)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "adminPayrollViewfrm"
        Me.Text = "adminPayrollViewfrm"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PayrollDS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PayrollDSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PayrollBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents PayrollDSBindingSource As BindingSource
    Friend WithEvents PayrollDS As PayrollDS
    Friend WithEvents PayrollBindingSource As BindingSource
    Friend WithEvents PayrollTableAdapter As PayrollDSTableAdapters.payrollTableAdapter
    Friend WithEvents StaffIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CvarDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BranchDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SalaryIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MonthlySalaryDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CommissionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeductionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BankAccDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents btnExit As Button
End Class
