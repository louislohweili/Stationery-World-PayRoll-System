﻿Public Class PayrollViewfrmupdate
    Public StrStaffID As String
    Public StrName As String
    Public StrBramch As String
    Public StrCvar As String
    Public StrSalaryID As String
    Public decMonthlySalary As Double
    Public decCommission As Double
    Public decDeduction As Decimal
    Public strBankAcc As String
    Public dblTotalSalaryMonthly As Double
    Private intRowPosition As Integer = 0
    Private Sub PayrollViewfrmupdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BranchDS.Branch' table. You can move, or remove it, as needed.
        Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
        'TODO: This line of code loads data into the 'PayrollDS.payroll' table. You can move, or remove it, as needed.
        Me.PayrollTableAdapter.Fill(Me.PayrollDS.payroll)

    End Sub
    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            txtStaffID.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("Staff_ID").ToString()
            txtName.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("Name").ToString()
            txtCvar.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("Cvar").ToString()
            txtBramch.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("Branch").ToString()
            txtSalaryID.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("Salary_ID").ToString()
            txtMonthlySalary.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("monthly Salary").ToString()
            txtCommission.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("commission").ToString()
            txtDeduction.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("deduction").ToString()
            txtBankAcc.Text = PayrollDS.Tables("Branch").Rows(intRowPosition)("Bank_Acc").ToString()
        End If
    End Sub

    Private Sub btmUpdateRecord_Click(sender As Object, e As EventArgs) Handles btmUpdateRecord.Click
        Dim newrow As DataRow = PayrollDS.Tables("Payroll").NewRow
        Try
            newrow("Staff_ID") = txtStaffID.Text
            newrow("Name") = txtName.Text
            newrow("Cvar") = txtCvar.Text
            newrow("Branch") = txtBramch.Text
            newrow("Salary_ID") = txtSalaryID.Text
            newrow("monthly Salary") = txtMonthlySalary.Text
            newrow("commission") = txtCommission.Text
            newrow("deduction") = txtDeduction.Text
            newrow("Bank_Acc") = txtBankAcc.Text

            PayrollDS.Tables("Payroll").Rows.Add(newrow)
            PayrollTableAdapter.Update(Me.PayrollDS.payroll)

            PayrollDS.AcceptChanges()
            MessageBox.Show("Record Update")
            Me.PayrollTableAdapter.Fill(Me.PayrollDS.payroll)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        StrStaffID = txtStaffID.Text
        StrName = txtName.Text
        StrCvar = txtCvar.Text
        StrBramch = txtBramch.Text
        StrSalaryID = txtSalaryID.Text
        decMonthlySalary = txtMonthlySalary.Text
        decCommission = txtCommission.Text
        decDeduction = txtDeduction.Text

        dblTotalSalaryMonthly = decMonthlySalary + decCommission - decDeduction
        MessageBox.Show(dblTotalSalaryMonthly)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtStaffID.Text = ""
        txtName.Text = ""
        txtCvar.Text = ""
        txtBramch.Text = ""
        txtSalaryID.Text = ""
        txtMonthlySalary.Text = ""
        txtCommission.Text = ""
        txtDeduction.Text = ""
        txtBankAcc.Text = ""
    End Sub
End Class