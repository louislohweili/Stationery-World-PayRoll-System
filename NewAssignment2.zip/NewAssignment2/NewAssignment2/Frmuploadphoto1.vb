﻿Public Class Frmuploadphoto1
    Dim strPath As String
    Dim strFilename As String
    Dim filname As String

    Private Sub btnUpload_Click(sender As System.Object, e As System.EventArgs) Handles btnupLoad.Click
        OpenPicture()
    End Sub

    Private Sub OpenPicture()
        If ofdPhoto.ShowDialog = DialogResult.OK Then
            ' Load the picture into the picture box.
            picShowPicture.Image = Image.FromFile(ofdPhoto.FileName)
            ' Show the name of the file in the form's label.
            strPath = ofdPhoto.FileName

            filname = Mid(strPath, InStrRev(strPath, "\", Len(strPath)) + 1, Len(strPath))
            strFilename = (Mid(filname, 1, InStr(filname, ".") - 1))

            lblcID.Text = strFilename
        End If
    End Sub



    Private Sub btnSavephoto_Click(sender As Object, e As EventArgs) Handles btnSavephoto.Click
        sfdPhoto.Title = "Specify Destination Filename"
        sfdPhoto.Filter = "Picture Files (*.jpg)|*.jpg"
        sfdPhoto.FileName = strFilename
        sfdPhoto.FilterIndex = 1

        sfdPhoto.OverwritePrompt = True

        If sfdPhoto.ShowDialog <> Windows.Forms.DialogResult.Cancel Then

            Dim FileToSaveAs As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp, sfdPhoto.FileName)
            picShowPicture.Image.Save(FileToSaveAs, System.Drawing.Imaging.ImageFormat.Jpeg)

        End If
    End Sub

    Private Sub Frmuploadphoto1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class