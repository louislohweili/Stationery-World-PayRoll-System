﻿Public Class managePayrollForm
    Public StrStaffID As String
    Public StrName As String
    Public StrBramch As String
    Public StrCvar As String
    Public StrSalaryID As String
    Public decMonthlySalary As Double
    Public decCommission As Double
    Public decDeduction As Decimal
    Public strBankAcc As String
    Public dblTotalSalaryMonthly As Double
    Private intRowPosition As Integer = 0

    Private Sub managePayrollForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PayrollDS3.payroll' table. You can move, or remove it, as needed.
        Me.PayrollTableAdapter.Fill(Me.PayrollDS3.payroll)
        ShowCurrentRecord()
    End Sub

    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            txtStaffID.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("Salary_ID").ToString()
            txtName.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("Name").ToString()
            txtCvar.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("Cvar").ToString()
            txtBramch.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("Branch").ToString()
            txtSalaryID.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("Salary_ID").ToString()
            txtMonthlySalary.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("monthly Salary")
            txtCommission.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("commission")
            txtDeduction.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("deduction")
            txtBankAcc.Text = PayrollDS3.Tables("Payroll").Rows(intRowPosition)("Bank_Acc").ToString()
            StrStaffID = txtStaffID.Text
            StrName = txtName.Text
            StrCvar = txtCvar.Text
            StrBramch = txtBramch.Text
            StrSalaryID = txtSalaryID.Text
            decMonthlySalary = txtMonthlySalary.Text
            decCommission = txtCommission.Text
            decDeduction = txtDeduction.Text

            dblTotalSalaryMonthly = decMonthlySalary + decCommission - decDeduction
            txtTotalSalaryMonthly.Text = dblTotalSalaryMonthly
        End If
    End Sub

    Private Sub btnMoveFirst_Click(sender As Object, e As EventArgs) Handles btnMoveFirst.Click
        intRowPosition = 0
        ShowCurrentRecord()
    End Sub

    Private Sub btnMoveLast_Click(sender As Object, e As EventArgs) Handles btnMoveLast.Click
        If PayrollDS3.Tables("Payroll").Rows.Count > 0 Then
            intRowPosition = PayrollDS3.Tables("Payroll").Rows.Count - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMovePrevious_Click(sender As Object, e As EventArgs) Handles btnMovePrevious.Click
        If intRowPosition > 0 Then
            intRowPosition = intRowPosition - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMoveNext_Click(sender As Object, e As EventArgs) Handles btnMoveNext.Click
        If intRowPosition < (PayrollDS3.Tables("Payroll").Rows.Count - 1) Then
            intRowPosition = intRowPosition + 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btmUpdateRecord_Click(sender As Object, e As EventArgs) Handles btmUpdateRecord.Click
        If PayrollDS3.Tables("payroll").Rows.Count <> 0 Then
            Try
                PayrollDS3.Tables("payroll").Rows(intRowPosition)("Staff_ID") = txtStaffID.Text
                PayrollDS3.Tables("payroll").Rows(intRowPosition)("Name") = txtName.Text
                PayrollDS3.Tables("payroll").Rows(intRowPosition)("Cvar") = txtCvar.Text
                PayrollDS3.Tables("payroll").Rows(intRowPosition)("Branch") = txtBramch.Text
                PayrollDS3.Tables("payroll").Rows(intRowPosition)("Salary_ID") = txtSalaryID.Text
                PayrollDS3.Tables("payroll").Rows(intRowPosition)("commission") = txtCommission.Text
                PayrollDS3.Tables("payroll").Rows(intRowPosition)("deduction") = txtDeduction.Text
                PayrollDS3.Tables("payroll").Rows(intRowPosition)("Bank_Acc") = txtBankAcc.Text
                PayrollTableAdapter.Update(PayrollDS3.payroll)
                PayrollDS3.AcceptChanges()
                MessageBox.Show("Record Update")
                Me.PayrollTableAdapter.Fill(PayrollDS3.payroll)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class