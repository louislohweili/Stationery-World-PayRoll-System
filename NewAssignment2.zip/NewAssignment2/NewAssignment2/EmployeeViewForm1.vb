﻿Public Class EmployeeViewForm1
    Private intRowPosition As Integer = 0
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EmployeeDS.Employee' table. You can move, or remove it, as needed.
        Me.EmployeeTableAdapter.Fill(Me.EmployeeDS.Employee)

    End Sub
    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            lblStaffID.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Staff_ID").ToString()
            lblName.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Name").ToString()
            lblDOB.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("DOB").ToString()
            lblGender.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Gender").ToString()
            lblEmail.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Email").ToString()
            lblHiredate.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Hire_date").ToString()
            lblCvar.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Cvar").ToString()
            lblBranch.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Branch").ToString()
            lblBranchno.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Branch_no").ToString()
            lblSalary.Text = FormatCurrency(EmployeeDS.Tables("Employee").Rows(intRowPosition)("Salary"))
        End If
    End Sub
    Private Sub btnMoveFirst_Click(sender As Object, e As EventArgs) Handles btnMoveFirst.Click
        intRowPosition = 0
        ShowCurrentRecord()
    End Sub

    Private Sub btnMoveLast_Click(sender As Object, e As EventArgs) Handles btnMoveLast.Click
        If EmployeeDS.Tables("Employee").Rows.Count > 0 Then
            intRowPosition = EmployeeDS.Tables("Employee").Rows.Count - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMovePrevious_Click(sender As Object, e As EventArgs) Handles btnMovePrevious.Click
        If intRowPosition > 0 Then
            intRowPosition = intRowPosition - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMoveNext_Click(sender As Object, e As EventArgs) Handles btnMoveNext.Click
        If intRowPosition < (EmployeeDS.Tables("Employee").Rows.Count - 1) Then
            intRowPosition = intRowPosition + 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMangeRecord_Click(sender As Object, e As EventArgs) Handles btnMangeRecord.Click
        MangaeEmployeeForm.ShowDialog()

    End Sub

    Private Sub btnRefreshDat_Click(sender As Object, e As EventArgs) Handles btnRefreshDat.Click
        Me.EmployeeTableAdapter.Fill(Me.EmployeeDS.Employee)
        ShowCurrentRecord()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
