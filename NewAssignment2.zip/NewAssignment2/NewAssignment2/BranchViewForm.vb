﻿Public Class BranchViewForm
    Private intRowPosition As Integer = 0

    Private Sub BranchViewForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BranchDS.Branch' table. You can move, or remove it, as needed.
        Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
    End Sub

    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            lblBranchID.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch_ID").ToString()
            lblBranchname.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch name").ToString()
            lblBranchaddress.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch address").ToString()
            lblCBranchcontactno.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch contact no").ToString()
            lblManageinchange.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Manage-in-change").ToString()
            lblBranchdata.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch data").ToString()

        End If
    End Sub

    Private Sub btnMoveFirst_Click(sender As Object, e As EventArgs) Handles btnMoveFirst.Click
        intRowPosition = 0
        Me.ShowCurrentRecord()
    End Sub

    Private Sub btnMoveLast_Click(sender As Object, e As EventArgs) Handles btnMoveLast.Click
        If BranchDS.Tables("Branch").Rows.Count > 0 Then
            intRowPosition = BranchDS.Tables("Branch").Rows.Count - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMovePrevious_Click(sender As Object, e As EventArgs) Handles btnMovePrevious.Click
        If intRowPosition > 0 Then
            intRowPosition = intRowPosition - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMoveNext_Click(sender As Object, e As EventArgs) Handles btnMoveNext.Click
        If intRowPosition < (BranchDS.Tables("Branch").Rows.Count - 1) Then
            intRowPosition = intRowPosition + 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnRefreshDat_Click(sender As Object, e As EventArgs) Handles btnRefreshDat.Click
        Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
        ShowCurrentRecord()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnMangeRecord_Click(sender As Object, e As EventArgs) Handles btnMangeRecord.Click
        MangaeBranchForm.ShowDialog()

    End Sub
End Class