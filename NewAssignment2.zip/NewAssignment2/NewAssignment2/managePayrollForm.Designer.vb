﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class managePayrollForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txtBramch = New System.Windows.Forms.ComboBox()
        Me.txtCvar = New System.Windows.Forms.ComboBox()
        Me.txtTotalSalaryMonthly = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnMoveNext = New System.Windows.Forms.Button()
        Me.btnMovePrevious = New System.Windows.Forms.Button()
        Me.btnMoveLast = New System.Windows.Forms.Button()
        Me.btnMoveFirst = New System.Windows.Forms.Button()
        Me.btnDeleteRecord = New System.Windows.Forms.Button()
        Me.btmUpdateRecord = New System.Windows.Forms.Button()
        Me.btnNewRecord = New System.Windows.Forms.Button()
        Me.btnRefreshDat = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtMonthlySalary = New System.Windows.Forms.TextBox()
        Me.txtBankAcc = New System.Windows.Forms.TextBox()
        Me.txtDeduction = New System.Windows.Forms.TextBox()
        Me.txtCommission = New System.Windows.Forms.TextBox()
        Me.txtSalaryID = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtStaffID = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.PayrollDS3 = New NewAssignment2.payrollDS3()
        Me.PayrollTableAdapter = New NewAssignment2.payrollDS3TableAdapters.payrollTableAdapter()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PayrollDS3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtBramch
        '
        Me.txtBramch.FormattingEnabled = True
        Me.txtBramch.Location = New System.Drawing.Point(310, 207)
        Me.txtBramch.Name = "txtBramch"
        Me.txtBramch.Size = New System.Drawing.Size(223, 24)
        Me.txtBramch.TabIndex = 188
        '
        'txtCvar
        '
        Me.txtCvar.FormattingEnabled = True
        Me.txtCvar.Items.AddRange(New Object() {"General Manager", "Manager", "HR Satff", "Supervisor", "Sale assitants"})
        Me.txtCvar.Location = New System.Drawing.Point(310, 157)
        Me.txtCvar.Name = "txtCvar"
        Me.txtCvar.Size = New System.Drawing.Size(223, 24)
        Me.txtCvar.TabIndex = 187
        '
        'txtTotalSalaryMonthly
        '
        Me.txtTotalSalaryMonthly.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.txtTotalSalaryMonthly.Location = New System.Drawing.Point(310, 533)
        Me.txtTotalSalaryMonthly.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtTotalSalaryMonthly.Name = "txtTotalSalaryMonthly"
        Me.txtTotalSalaryMonthly.ReadOnly = True
        Me.txtTotalSalaryMonthly.Size = New System.Drawing.Size(223, 22)
        Me.txtTotalSalaryMonthly.TabIndex = 186
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(43, 535)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(187, 20)
        Me.Label11.TabIndex = 185
        Me.Label11.Text = "Total Salary Monthly:"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(729, 352)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(136, 28)
        Me.btnExit.TabIndex = 184
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnMoveNext
        '
        Me.btnMoveNext.Location = New System.Drawing.Point(452, 593)
        Me.btnMoveNext.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnMoveNext.Name = "btnMoveNext"
        Me.btnMoveNext.Size = New System.Drawing.Size(92, 39)
        Me.btnMoveNext.TabIndex = 183
        Me.btnMoveNext.Text = ">"
        Me.btnMoveNext.UseVisualStyleBackColor = True
        '
        'btnMovePrevious
        '
        Me.btnMovePrevious.Location = New System.Drawing.Point(291, 593)
        Me.btnMovePrevious.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnMovePrevious.Name = "btnMovePrevious"
        Me.btnMovePrevious.Size = New System.Drawing.Size(99, 39)
        Me.btnMovePrevious.TabIndex = 182
        Me.btnMovePrevious.Text = "<"
        Me.btnMovePrevious.UseVisualStyleBackColor = True
        '
        'btnMoveLast
        '
        Me.btnMoveLast.Location = New System.Drawing.Point(153, 593)
        Me.btnMoveLast.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnMoveLast.Name = "btnMoveLast"
        Me.btnMoveLast.Size = New System.Drawing.Size(88, 39)
        Me.btnMoveLast.TabIndex = 181
        Me.btnMoveLast.Text = "<<"
        Me.btnMoveLast.UseVisualStyleBackColor = True
        '
        'btnMoveFirst
        '
        Me.btnMoveFirst.Location = New System.Drawing.Point(586, 593)
        Me.btnMoveFirst.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnMoveFirst.Name = "btnMoveFirst"
        Me.btnMoveFirst.Size = New System.Drawing.Size(104, 39)
        Me.btnMoveFirst.TabIndex = 180
        Me.btnMoveFirst.Text = ">>"
        Me.btnMoveFirst.UseVisualStyleBackColor = True
        '
        'btnDeleteRecord
        '
        Me.btnDeleteRecord.Location = New System.Drawing.Point(729, 135)
        Me.btnDeleteRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDeleteRecord.Name = "btnDeleteRecord"
        Me.btnDeleteRecord.Size = New System.Drawing.Size(136, 28)
        Me.btnDeleteRecord.TabIndex = 179
        Me.btnDeleteRecord.Text = "Delete Record"
        Me.btnDeleteRecord.UseVisualStyleBackColor = True
        '
        'btmUpdateRecord
        '
        Me.btmUpdateRecord.Location = New System.Drawing.Point(729, 85)
        Me.btmUpdateRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btmUpdateRecord.Name = "btmUpdateRecord"
        Me.btmUpdateRecord.Size = New System.Drawing.Size(136, 28)
        Me.btmUpdateRecord.TabIndex = 178
        Me.btmUpdateRecord.Text = "Update Record"
        Me.btmUpdateRecord.UseVisualStyleBackColor = True
        '
        'btnNewRecord
        '
        Me.btnNewRecord.Location = New System.Drawing.Point(729, 200)
        Me.btnNewRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btnNewRecord.Name = "btnNewRecord"
        Me.btnNewRecord.Size = New System.Drawing.Size(136, 28)
        Me.btnNewRecord.TabIndex = 177
        Me.btnNewRecord.Text = "New Record"
        Me.btnNewRecord.UseVisualStyleBackColor = True
        '
        'btnRefreshDat
        '
        Me.btnRefreshDat.Location = New System.Drawing.Point(729, 280)
        Me.btnRefreshDat.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRefreshDat.Name = "btnRefreshDat"
        Me.btnRefreshDat.Size = New System.Drawing.Size(136, 28)
        Me.btnRefreshDat.TabIndex = 176
        Me.btnRefreshDat.Text = "Refresh Data"
        Me.btnRefreshDat.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(149, 8)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(449, 25)
        Me.Label1.TabIndex = 175
        Me.Label1.Text = "Welcome to Stationery World Payroll System "
        '
        'txtMonthlySalary
        '
        Me.txtMonthlySalary.Location = New System.Drawing.Point(310, 315)
        Me.txtMonthlySalary.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtMonthlySalary.Name = "txtMonthlySalary"
        Me.txtMonthlySalary.Size = New System.Drawing.Size(223, 22)
        Me.txtMonthlySalary.TabIndex = 174
        '
        'txtBankAcc
        '
        Me.txtBankAcc.Location = New System.Drawing.Point(310, 494)
        Me.txtBankAcc.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBankAcc.Name = "txtBankAcc"
        Me.txtBankAcc.Size = New System.Drawing.Size(223, 22)
        Me.txtBankAcc.TabIndex = 173
        '
        'txtDeduction
        '
        Me.txtDeduction.Location = New System.Drawing.Point(310, 419)
        Me.txtDeduction.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtDeduction.Name = "txtDeduction"
        Me.txtDeduction.Size = New System.Drawing.Size(223, 22)
        Me.txtDeduction.TabIndex = 172
        '
        'txtCommission
        '
        Me.txtCommission.Location = New System.Drawing.Point(310, 360)
        Me.txtCommission.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtCommission.Name = "txtCommission"
        Me.txtCommission.Size = New System.Drawing.Size(223, 22)
        Me.txtCommission.TabIndex = 171
        '
        'txtSalaryID
        '
        Me.txtSalaryID.Location = New System.Drawing.Point(310, 261)
        Me.txtSalaryID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtSalaryID.Name = "txtSalaryID"
        Me.txtSalaryID.Size = New System.Drawing.Size(223, 22)
        Me.txtSalaryID.TabIndex = 170
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(310, 97)
        Me.txtName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(223, 22)
        Me.txtName.TabIndex = 169
        '
        'txtStaffID
        '
        Me.txtStaffID.Location = New System.Drawing.Point(310, 53)
        Me.txtStaffID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.ReadOnly = True
        Me.txtStaffID.Size = New System.Drawing.Size(223, 22)
        Me.txtStaffID.TabIndex = 168
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(130, 421)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 20)
        Me.Label10.TabIndex = 167
        Me.Label10.Text = "Deduction:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(112, 362)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(118, 20)
        Me.Label9.TabIndex = 166
        Me.Label9.Text = "Commission:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(135, 494)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 20)
        Me.Label8.TabIndex = 165
        Me.Label8.Text = "Bank Acc:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(91, 315)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(139, 20)
        Me.Label7.TabIndex = 164
        Me.Label7.Text = "Monthly Salary:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(137, 261)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 20)
        Me.Label6.TabIndex = 163
        Me.Label6.Text = "Salary ID:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(149, 207)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 20)
        Me.Label5.TabIndex = 162
        Me.Label5.Text = "Branch :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(176, 157)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 20)
        Me.Label4.TabIndex = 161
        Me.Label4.Text = "Cvar:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(167, 98)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 160
        Me.Label3.Text = "Name:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(167, 53)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(80, 20)
        Me.label2.TabIndex = 159
        Me.label2.Text = "Staff ID:"
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "payroll"
        Me.BindingSource1.DataSource = Me.PayrollDS3
        '
        'PayrollDS3
        '
        Me.PayrollDS3.DataSetName = "payrollDS3"
        Me.PayrollDS3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PayrollTableAdapter
        '
        Me.PayrollTableAdapter.ClearBeforeFill = True
        '
        'managePayrollForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(908, 646)
        Me.Controls.Add(Me.txtBramch)
        Me.Controls.Add(Me.txtCvar)
        Me.Controls.Add(Me.txtTotalSalaryMonthly)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnMoveNext)
        Me.Controls.Add(Me.btnMovePrevious)
        Me.Controls.Add(Me.btnMoveLast)
        Me.Controls.Add(Me.btnMoveFirst)
        Me.Controls.Add(Me.btnDeleteRecord)
        Me.Controls.Add(Me.btmUpdateRecord)
        Me.Controls.Add(Me.btnNewRecord)
        Me.Controls.Add(Me.btnRefreshDat)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtMonthlySalary)
        Me.Controls.Add(Me.txtBankAcc)
        Me.Controls.Add(Me.txtDeduction)
        Me.Controls.Add(Me.txtCommission)
        Me.Controls.Add(Me.txtSalaryID)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtStaffID)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.label2)
        Me.Name = "managePayrollForm"
        Me.Text = "managePayrollForm"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PayrollDS3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtBramch As ComboBox
    Friend WithEvents txtCvar As ComboBox
    Friend WithEvents txtTotalSalaryMonthly As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnMoveNext As Button
    Friend WithEvents btnMovePrevious As Button
    Friend WithEvents btnMoveLast As Button
    Friend WithEvents btnMoveFirst As Button
    Friend WithEvents btnDeleteRecord As Button
    Friend WithEvents btmUpdateRecord As Button
    Friend WithEvents btnNewRecord As Button
    Friend WithEvents btnRefreshDat As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtMonthlySalary As TextBox
    Friend WithEvents txtBankAcc As TextBox
    Friend WithEvents txtDeduction As TextBox
    Friend WithEvents txtCommission As TextBox
    Friend WithEvents txtSalaryID As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtStaffID As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents label2 As Label
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents PayrollDS3 As payrollDS3
    Friend WithEvents PayrollTableAdapter As payrollDS3TableAdapters.payrollTableAdapter
End Class
