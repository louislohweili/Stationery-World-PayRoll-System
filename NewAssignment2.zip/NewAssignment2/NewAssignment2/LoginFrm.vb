﻿Public Class LoginFrm
    Private Sub LoginFrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LoginDS.Login' table. You can move, or remove it, as needed.
        Me.LoginTableAdapter.Fill(Me.LoginDS.Login)

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim SearchAccount As LoginDS.LoginRow
        Dim intFound As Integer = 0

        For Each SearchAccount In LoginDS.Login.Rows
            If SearchAccount.Username = txtUsername.Text Then

                intFound = 1
                Try
                    If SearchAccount.Password = txtPassword.Text Then
                        If SearchAccount.role = "HRStaff" Then
                            MessageBox.Show("you are  a HR Staff")
                            HrStaffmainFrm.ShowDialog()
                        ElseIf SearchAccount.role = "Admin" Then
                            MessageBox.Show("you are  a Admin")
                            AdminMainFrm.ShowDialog()
                        ElseIf SearchAccount.role = "Supervisor" Then
                            MessageBox.Show("you are  a Supervisor")
                            SupervisorMainFrm.ShowDialog()
                        End If
                    Else
                        MessageBox.Show("Invalid Password")
                    End If
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
            End If
        Next SearchAccount
        If intFound = 0 Then
            MessageBox.Show("Invalid Username")
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtUsername.Text = ""
        txtPassword.Text = ""
    End Sub
End Class