﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EmployeeviewFormUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btmUpdateRecord = New System.Windows.Forms.Button()
        Me.txtSalary = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtStaffID = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmployeeDS = New NewAssignment2.EmployeeDS()
        Me.EmployeeTableAdapter = New NewAssignment2.EmployeeDSTableAdapters.EmployeeTableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblSalary = New System.Windows.Forms.Label()
        Me.lblBranchno = New System.Windows.Forms.Label()
        Me.lblBranch = New System.Windows.Forms.Label()
        Me.lblHiredate = New System.Windows.Forms.Label()
        Me.lblCvar = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblGender = New System.Windows.Forms.Label()
        Me.lblDOB = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblStaffID = New System.Windows.Forms.Label()
        Me.txtDOB = New System.Windows.Forms.DateTimePicker()
        Me.EmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.txtHireDate = New System.Windows.Forms.DateTimePicker()
        Me.EmployeeBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmployeeDSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchDS = New NewAssignment2.BranchDS()
        Me.txtBranch = New System.Windows.Forms.ComboBox()
        Me.txtBranchNo = New System.Windows.Forms.ComboBox()
        Me.BranchBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchDSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchTableAdapter = New NewAssignment2.BranchDSTableAdapters.BranchTableAdapter()
        Me.txtGender = New System.Windows.Forms.ComboBox()
        Me.txtCvar = New System.Windows.Forms.ComboBox()
        Me.btnuploadphoto = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeDS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeDSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchDSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btmUpdateRecord
        '
        Me.btmUpdateRecord.Location = New System.Drawing.Point(684, 184)
        Me.btmUpdateRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btmUpdateRecord.Name = "btmUpdateRecord"
        Me.btmUpdateRecord.Size = New System.Drawing.Size(136, 28)
        Me.btmUpdateRecord.TabIndex = 123
        Me.btmUpdateRecord.Text = "Update Record"
        Me.btmUpdateRecord.UseVisualStyleBackColor = True
        '
        'txtSalary
        '
        Me.txtSalary.Location = New System.Drawing.Point(317, 651)
        Me.txtSalary.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtSalary.Name = "txtSalary"
        Me.txtSalary.Size = New System.Drawing.Size(223, 22)
        Me.txtSalary.TabIndex = 118
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(317, 374)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(223, 22)
        Me.txtEmail.TabIndex = 110
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(307, 190)
        Me.txtName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(223, 22)
        Me.txtName.TabIndex = 109
        '
        'txtStaffID
        '
        Me.txtStaffID.Location = New System.Drawing.Point(307, 120)
        Me.txtStaffID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.Size = New System.Drawing.Size(223, 22)
        Me.txtStaffID.TabIndex = 108
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(203, 30)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(449, 25)
        Me.Label8.TabIndex = 100
        Me.Label8.Text = "Welcome to Stationery World Payroll System "
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(748, 707)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(99, 39)
        Me.btnExit.TabIndex = 101
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "Employee"
        Me.BindingSource1.DataSource = Me.EmployeeDS
        '
        'EmployeeDS
        '
        Me.EmployeeDS.DataSetName = "EmployeeDS"
        Me.EmployeeDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EmployeeTableAdapter
        '
        Me.EmployeeTableAdapter.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(544, 796)
        Me.Button1.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(146, 35)
        Me.Button1.TabIndex = 134
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblSalary
        '
        Me.lblSalary.AutoSize = True
        Me.lblSalary.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalary.Location = New System.Drawing.Point(215, 656)
        Me.lblSalary.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblSalary.Name = "lblSalary"
        Me.lblSalary.Size = New System.Drawing.Size(64, 17)
        Me.lblSalary.TabIndex = 133
        Me.lblSalary.Text = "Salary :"
        '
        'lblBranchno
        '
        Me.lblBranchno.AutoSize = True
        Me.lblBranchno.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBranchno.Location = New System.Drawing.Point(195, 608)
        Me.lblBranchno.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblBranchno.Name = "lblBranchno"
        Me.lblBranchno.Size = New System.Drawing.Size(92, 17)
        Me.lblBranchno.TabIndex = 132
        Me.lblBranchno.Text = "Branch no :"
        '
        'lblBranch
        '
        Me.lblBranch.AutoSize = True
        Me.lblBranch.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBranch.Location = New System.Drawing.Point(218, 552)
        Me.lblBranch.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblBranch.Name = "lblBranch"
        Me.lblBranch.Size = New System.Drawing.Size(69, 17)
        Me.lblBranch.TabIndex = 131
        Me.lblBranch.Text = "Branch :"
        '
        'lblHiredate
        '
        Me.lblHiredate.AutoSize = True
        Me.lblHiredate.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHiredate.Location = New System.Drawing.Point(202, 432)
        Me.lblHiredate.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblHiredate.Name = "lblHiredate"
        Me.lblHiredate.Size = New System.Drawing.Size(85, 17)
        Me.lblHiredate.TabIndex = 130
        Me.lblHiredate.Text = "Hire date :"
        '
        'lblCvar
        '
        Me.lblCvar.AutoSize = True
        Me.lblCvar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCvar.Location = New System.Drawing.Point(236, 486)
        Me.lblCvar.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblCvar.Name = "lblCvar"
        Me.lblCvar.Size = New System.Drawing.Size(46, 17)
        Me.lblCvar.TabIndex = 129
        Me.lblCvar.Text = "Cvar:"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(230, 374)
        Me.lblEmail.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(57, 17)
        Me.lblEmail.TabIndex = 128
        Me.lblEmail.Text = "Email :"
        '
        'lblGender
        '
        Me.lblGender.AutoSize = True
        Me.lblGender.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGender.Location = New System.Drawing.Point(215, 316)
        Me.lblGender.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblGender.Name = "lblGender"
        Me.lblGender.Size = New System.Drawing.Size(72, 17)
        Me.lblGender.TabIndex = 127
        Me.lblGender.Text = "Gender :"
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDOB.Location = New System.Drawing.Point(236, 247)
        Me.lblDOB.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(51, 17)
        Me.lblDOB.TabIndex = 126
        Me.lblDOB.Text = "DOB :"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(223, 190)
        Me.lblName.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(59, 17)
        Me.lblName.TabIndex = 125
        Me.lblName.Text = "Name :"
        '
        'lblStaffID
        '
        Me.lblStaffID.AutoSize = True
        Me.lblStaffID.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStaffID.Location = New System.Drawing.Point(215, 120)
        Me.lblStaffID.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lblStaffID.Name = "lblStaffID"
        Me.lblStaffID.Size = New System.Drawing.Size(72, 17)
        Me.lblStaffID.TabIndex = 124
        Me.lblStaffID.Text = "Staff ID :"
        '
        'txtDOB
        '
        Me.txtDOB.Location = New System.Drawing.Point(307, 242)
        Me.txtDOB.Name = "txtDOB"
        Me.txtDOB.Size = New System.Drawing.Size(223, 22)
        Me.txtDOB.TabIndex = 135
        '
        'EmployeeBindingSource
        '
        Me.EmployeeBindingSource.DataMember = "Employee"
        Me.EmployeeBindingSource.DataSource = Me.EmployeeDS
        '
        'txtHireDate
        '
        Me.txtHireDate.Location = New System.Drawing.Point(317, 427)
        Me.txtHireDate.Name = "txtHireDate"
        Me.txtHireDate.Size = New System.Drawing.Size(223, 22)
        Me.txtHireDate.TabIndex = 137
        '
        'EmployeeBindingSource1
        '
        Me.EmployeeBindingSource1.DataMember = "Employee"
        Me.EmployeeBindingSource1.DataSource = Me.EmployeeDSBindingSource
        '
        'EmployeeDSBindingSource
        '
        Me.EmployeeDSBindingSource.DataSource = Me.EmployeeDS
        Me.EmployeeDSBindingSource.Position = 0
        '
        'BranchDS
        '
        Me.BranchDS.DataSetName = "BranchDS"
        Me.BranchDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtBranch
        '
        Me.txtBranch.DataSource = Me.BranchDS
        Me.txtBranch.DisplayMember = "Branch.Branch name"
        Me.txtBranch.FormattingEnabled = True
        Me.txtBranch.Location = New System.Drawing.Point(317, 545)
        Me.txtBranch.Name = "txtBranch"
        Me.txtBranch.Size = New System.Drawing.Size(223, 24)
        Me.txtBranch.TabIndex = 140
        '
        'txtBranchNo
        '
        Me.txtBranchNo.DataSource = Me.BranchBindingSource
        Me.txtBranchNo.DisplayMember = "Branch_ID"
        Me.txtBranchNo.FormattingEnabled = True
        Me.txtBranchNo.Location = New System.Drawing.Point(317, 601)
        Me.txtBranchNo.Name = "txtBranchNo"
        Me.txtBranchNo.Size = New System.Drawing.Size(223, 24)
        Me.txtBranchNo.TabIndex = 141
        '
        'BranchBindingSource
        '
        Me.BranchBindingSource.DataMember = "Branch"
        Me.BranchBindingSource.DataSource = Me.BranchDSBindingSource
        '
        'BranchDSBindingSource
        '
        Me.BranchDSBindingSource.DataSource = Me.BranchDS
        Me.BranchDSBindingSource.Position = 0
        '
        'BranchTableAdapter
        '
        Me.BranchTableAdapter.ClearBeforeFill = True
        '
        'txtGender
        '
        Me.txtGender.FormattingEnabled = True
        Me.txtGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.txtGender.Location = New System.Drawing.Point(307, 313)
        Me.txtGender.Name = "txtGender"
        Me.txtGender.Size = New System.Drawing.Size(223, 24)
        Me.txtGender.TabIndex = 142
        '
        'txtCvar
        '
        Me.txtCvar.FormattingEnabled = True
        Me.txtCvar.Items.AddRange(New Object() {"General Manager", "Manager", "HR Satff", "Supervisor", "Sale assitants"})
        Me.txtCvar.Location = New System.Drawing.Point(317, 479)
        Me.txtCvar.Name = "txtCvar"
        Me.txtCvar.Size = New System.Drawing.Size(223, 24)
        Me.txtCvar.TabIndex = 143
        '
        'btnuploadphoto
        '
        Me.btnuploadphoto.Location = New System.Drawing.Point(684, 257)
        Me.btnuploadphoto.Margin = New System.Windows.Forms.Padding(4)
        Me.btnuploadphoto.Name = "btnuploadphoto"
        Me.btnuploadphoto.Size = New System.Drawing.Size(136, 28)
        Me.btnuploadphoto.TabIndex = 144
        Me.btnuploadphoto.Text = "Upload photo"
        Me.btnuploadphoto.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(594, 707)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(99, 39)
        Me.btnClear.TabIndex = 145
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'EmployeeviewFormUpdate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(860, 759)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnuploadphoto)
        Me.Controls.Add(Me.txtCvar)
        Me.Controls.Add(Me.txtGender)
        Me.Controls.Add(Me.txtBranchNo)
        Me.Controls.Add(Me.txtBranch)
        Me.Controls.Add(Me.txtHireDate)
        Me.Controls.Add(Me.txtDOB)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblSalary)
        Me.Controls.Add(Me.lblBranchno)
        Me.Controls.Add(Me.lblBranch)
        Me.Controls.Add(Me.lblHiredate)
        Me.Controls.Add(Me.lblCvar)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblGender)
        Me.Controls.Add(Me.lblDOB)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.lblStaffID)
        Me.Controls.Add(Me.btmUpdateRecord)
        Me.Controls.Add(Me.txtSalary)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtStaffID)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "EmployeeviewFormUpdate"
        Me.Text = "EmployeeviewFormUpdate"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeDS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeDSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchDSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btmUpdateRecord As Button
    Friend WithEvents txtSalary As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtStaffID As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents EmployeeDS As EmployeeDS
    Friend WithEvents EmployeeTableAdapter As EmployeeDSTableAdapters.EmployeeTableAdapter
    Friend WithEvents Button1 As Button
    Friend WithEvents lblSalary As Label
    Friend WithEvents lblBranchno As Label
    Friend WithEvents lblBranch As Label
    Friend WithEvents lblHiredate As Label
    Friend WithEvents lblCvar As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents lblGender As Label
    Friend WithEvents lblDOB As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblStaffID As Label
    Friend WithEvents txtDOB As DateTimePicker
    Friend WithEvents EmployeeBindingSource As BindingSource
    Friend WithEvents txtHireDate As DateTimePicker
    Friend WithEvents EmployeeBindingSource1 As BindingSource
    Friend WithEvents EmployeeDSBindingSource As BindingSource
    Friend WithEvents BranchDS As BranchDS
    Friend WithEvents txtBranch As ComboBox
    Friend WithEvents txtBranchNo As ComboBox
    Friend WithEvents BranchDSBindingSource As BindingSource
    Friend WithEvents BranchBindingSource As BindingSource
    Friend WithEvents BranchTableAdapter As BranchDSTableAdapters.BranchTableAdapter
    Friend WithEvents txtGender As ComboBox
    Friend WithEvents txtCvar As ComboBox
    Friend WithEvents btnuploadphoto As Button
    Friend WithEvents btnClear As Button
End Class
