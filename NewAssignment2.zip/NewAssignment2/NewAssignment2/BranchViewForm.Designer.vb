﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BranchViewForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnMangeRecord = New System.Windows.Forms.Button()
        Me.btnRefreshDat = New System.Windows.Forms.Button()
        Me.btnMoveNext = New System.Windows.Forms.Button()
        Me.btnMovePrevious = New System.Windows.Forms.Button()
        Me.btnMoveLast = New System.Windows.Forms.Button()
        Me.btnMoveFirst = New System.Windows.Forms.Button()
        Me.lblBranchdata = New System.Windows.Forms.Label()
        Me.lblManageinchange = New System.Windows.Forms.Label()
        Me.lblCBranchcontactno = New System.Windows.Forms.Label()
        Me.lblBranchaddress = New System.Windows.Forms.Label()
        Me.lblBranchname = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblBranchID = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchDS = New NewAssignment2.BranchDS()
        Me.BranchTableAdapter = New NewAssignment2.BranchDSTableAdapters.BranchTableAdapter()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnMangeRecord
        '
        Me.btnMangeRecord.Location = New System.Drawing.Point(253, 474)
        Me.btnMangeRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btnMangeRecord.Name = "btnMangeRecord"
        Me.btnMangeRecord.Size = New System.Drawing.Size(136, 28)
        Me.btnMangeRecord.TabIndex = 69
        Me.btnMangeRecord.Text = "Manage Record"
        Me.btnMangeRecord.UseVisualStyleBackColor = True
        '
        'btnRefreshDat
        '
        Me.btnRefreshDat.Location = New System.Drawing.Point(44, 474)
        Me.btnRefreshDat.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRefreshDat.Name = "btnRefreshDat"
        Me.btnRefreshDat.Size = New System.Drawing.Size(136, 28)
        Me.btnRefreshDat.TabIndex = 68
        Me.btnRefreshDat.Text = "Refresh Data"
        Me.btnRefreshDat.UseVisualStyleBackColor = True
        '
        'btnMoveNext
        '
        Me.btnMoveNext.Location = New System.Drawing.Point(397, 406)
        Me.btnMoveNext.Margin = New System.Windows.Forms.Padding(4)
        Me.btnMoveNext.Name = "btnMoveNext"
        Me.btnMoveNext.Size = New System.Drawing.Size(100, 31)
        Me.btnMoveNext.TabIndex = 67
        Me.btnMoveNext.Text = ">>"
        Me.btnMoveNext.UseVisualStyleBackColor = True
        '
        'btnMovePrevious
        '
        Me.btnMovePrevious.Location = New System.Drawing.Point(289, 406)
        Me.btnMovePrevious.Margin = New System.Windows.Forms.Padding(4)
        Me.btnMovePrevious.Name = "btnMovePrevious"
        Me.btnMovePrevious.Size = New System.Drawing.Size(100, 31)
        Me.btnMovePrevious.TabIndex = 66
        Me.btnMovePrevious.Text = ">"
        Me.btnMovePrevious.UseVisualStyleBackColor = True
        '
        'btnMoveLast
        '
        Me.btnMoveLast.Location = New System.Drawing.Point(162, 406)
        Me.btnMoveLast.Margin = New System.Windows.Forms.Padding(4)
        Me.btnMoveLast.Name = "btnMoveLast"
        Me.btnMoveLast.Size = New System.Drawing.Size(100, 31)
        Me.btnMoveLast.TabIndex = 65
        Me.btnMoveLast.Text = "<"
        Me.btnMoveLast.UseVisualStyleBackColor = True
        '
        'btnMoveFirst
        '
        Me.btnMoveFirst.Location = New System.Drawing.Point(25, 406)
        Me.btnMoveFirst.Margin = New System.Windows.Forms.Padding(4)
        Me.btnMoveFirst.Name = "btnMoveFirst"
        Me.btnMoveFirst.Size = New System.Drawing.Size(100, 31)
        Me.btnMoveFirst.TabIndex = 64
        Me.btnMoveFirst.Text = "<<"
        Me.btnMoveFirst.UseVisualStyleBackColor = True
        '
        'lblBranchdata
        '
        Me.lblBranchdata.AutoSize = True
        Me.lblBranchdata.Location = New System.Drawing.Point(293, 363)
        Me.lblBranchdata.Name = "lblBranchdata"
        Me.lblBranchdata.Size = New System.Drawing.Size(59, 17)
        Me.lblBranchdata.TabIndex = 63
        Me.lblBranchdata.Text = "Label13"
        '
        'lblManageinchange
        '
        Me.lblManageinchange.AutoSize = True
        Me.lblManageinchange.Location = New System.Drawing.Point(293, 309)
        Me.lblManageinchange.Name = "lblManageinchange"
        Me.lblManageinchange.Size = New System.Drawing.Size(59, 17)
        Me.lblManageinchange.TabIndex = 62
        Me.lblManageinchange.Text = "Label12"
        '
        'lblCBranchcontactno
        '
        Me.lblCBranchcontactno.AutoSize = True
        Me.lblCBranchcontactno.Location = New System.Drawing.Point(293, 241)
        Me.lblCBranchcontactno.Name = "lblCBranchcontactno"
        Me.lblCBranchcontactno.Size = New System.Drawing.Size(59, 17)
        Me.lblCBranchcontactno.TabIndex = 61
        Me.lblCBranchcontactno.Text = "Label11"
        '
        'lblBranchaddress
        '
        Me.lblBranchaddress.AutoSize = True
        Me.lblBranchaddress.Location = New System.Drawing.Point(293, 198)
        Me.lblBranchaddress.Name = "lblBranchaddress"
        Me.lblBranchaddress.Size = New System.Drawing.Size(59, 17)
        Me.lblBranchaddress.TabIndex = 60
        Me.lblBranchaddress.Text = "Label10"
        '
        'lblBranchname
        '
        Me.lblBranchname.AutoSize = True
        Me.lblBranchname.Location = New System.Drawing.Point(301, 130)
        Me.lblBranchname.Name = "lblBranchname"
        Me.lblBranchname.Size = New System.Drawing.Size(51, 17)
        Me.lblBranchname.TabIndex = 59
        Me.lblBranchname.Text = "Label9"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(116, 360)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(123, 20)
        Me.Label7.TabIndex = 57
        Me.Label7.Text = "Branch data :"
        '
        'lblBranchID
        '
        Me.lblBranchID.AutoSize = True
        Me.lblBranchID.Location = New System.Drawing.Point(301, 80)
        Me.lblBranchID.Name = "lblBranchID"
        Me.lblBranchID.Size = New System.Drawing.Size(51, 17)
        Me.lblBranchID.TabIndex = 58
        Me.lblBranchID.Text = "Label8"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(67, 306)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(174, 20)
        Me.Label6.TabIndex = 56
        Me.Label6.Text = "Manage in-change :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(70, 238)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(169, 20)
        Me.Label5.TabIndex = 55
        Me.Label5.Text = "Branch contact no:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(80, 195)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 20)
        Me.Label4.TabIndex = 54
        Me.Label4.Text = "Branch address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(91, 127)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(126, 20)
        Me.Label3.TabIndex = 53
        Me.Label3.Text = "Branch name:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(104, 77)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 20)
        Me.Label9.TabIndex = 52
        Me.Label9.Text = "Branch ID:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(104, 77)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(100, 20)
        Me.label2.TabIndex = 51
        Me.label2.Text = "Branch ID:"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(507, 502)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(99, 39)
        Me.btnExit.TabIndex = 50
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(103, 1)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(449, 25)
        Me.Label8.TabIndex = 49
        Me.Label8.Text = "Welcome to Stationery World Payroll System "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(103, 1)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(449, 25)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "Welcome to Stationery World Payroll System "
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "Branch"
        Me.BindingSource1.DataSource = Me.BranchDS
        '
        'BranchDS
        '
        Me.BranchDS.DataSetName = "BranchDS"
        Me.BranchDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BranchTableAdapter
        '
        Me.BranchTableAdapter.ClearBeforeFill = True
        '
        'BranchViewForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(624, 549)
        Me.Controls.Add(Me.btnMangeRecord)
        Me.Controls.Add(Me.btnRefreshDat)
        Me.Controls.Add(Me.btnMoveNext)
        Me.Controls.Add(Me.btnMovePrevious)
        Me.Controls.Add(Me.btnMoveLast)
        Me.Controls.Add(Me.btnMoveFirst)
        Me.Controls.Add(Me.lblBranchdata)
        Me.Controls.Add(Me.lblManageinchange)
        Me.Controls.Add(Me.lblCBranchcontactno)
        Me.Controls.Add(Me.lblBranchaddress)
        Me.Controls.Add(Me.lblBranchname)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblBranchID)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label1)
        Me.Name = "BranchViewForm"
        Me.Text = "BranchViewForm"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnMangeRecord As Button
    Friend WithEvents btnRefreshDat As Button
    Friend WithEvents btnMoveNext As Button
    Friend WithEvents btnMovePrevious As Button
    Friend WithEvents btnMoveLast As Button
    Friend WithEvents btnMoveFirst As Button
    Friend WithEvents lblBranchdata As Label
    Friend WithEvents lblManageinchange As Label
    Friend WithEvents lblCBranchcontactno As Label
    Friend WithEvents lblBranchaddress As Label
    Friend WithEvents lblBranchname As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents lblBranchID As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents label2 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents BranchDS As BranchDS
    Friend WithEvents BranchTableAdapter As BranchDSTableAdapters.BranchTableAdapter
End Class
