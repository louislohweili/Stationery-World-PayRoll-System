﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PayrollViewfrmupdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btmUpdateRecord = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtMonthlySalary = New System.Windows.Forms.TextBox()
        Me.txtBankAcc = New System.Windows.Forms.TextBox()
        Me.txtDeduction = New System.Windows.Forms.TextBox()
        Me.txtCommission = New System.Windows.Forms.TextBox()
        Me.txtSalaryID = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtStaffID = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.PayrollDS = New NewAssignment2.PayrollDS()
        Me.PayrollTableAdapter = New NewAssignment2.PayrollDSTableAdapters.payrollTableAdapter()
        Me.txtCvar = New System.Windows.Forms.ComboBox()
        Me.txtBramch = New System.Windows.Forms.ComboBox()
        Me.BranchBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchDS = New NewAssignment2.BranchDS()
        Me.BranchTableAdapter = New NewAssignment2.BranchDSTableAdapters.BranchTableAdapter()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PayrollDS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btmUpdateRecord
        '
        Me.btmUpdateRecord.Location = New System.Drawing.Point(629, 58)
        Me.btmUpdateRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btmUpdateRecord.Name = "btmUpdateRecord"
        Me.btmUpdateRecord.Size = New System.Drawing.Size(136, 28)
        Me.btmUpdateRecord.TabIndex = 126
        Me.btmUpdateRecord.Text = "Update Record"
        Me.btmUpdateRecord.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(515, 512)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(99, 37)
        Me.btnClear.TabIndex = 125
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(676, 512)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(99, 37)
        Me.btnExit.TabIndex = 124
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(84, 0)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(449, 25)
        Me.Label1.TabIndex = 123
        Me.Label1.Text = "Welcome to Stationery World Payroll System "
        '
        'txtMonthlySalary
        '
        Me.txtMonthlySalary.Location = New System.Drawing.Point(245, 307)
        Me.txtMonthlySalary.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtMonthlySalary.Name = "txtMonthlySalary"
        Me.txtMonthlySalary.Size = New System.Drawing.Size(223, 22)
        Me.txtMonthlySalary.TabIndex = 122
        '
        'txtBankAcc
        '
        Me.txtBankAcc.Location = New System.Drawing.Point(245, 486)
        Me.txtBankAcc.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBankAcc.Name = "txtBankAcc"
        Me.txtBankAcc.Size = New System.Drawing.Size(223, 22)
        Me.txtBankAcc.TabIndex = 119
        '
        'txtDeduction
        '
        Me.txtDeduction.Location = New System.Drawing.Point(245, 400)
        Me.txtDeduction.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtDeduction.Name = "txtDeduction"
        Me.txtDeduction.Size = New System.Drawing.Size(223, 22)
        Me.txtDeduction.TabIndex = 118
        '
        'txtCommission
        '
        Me.txtCommission.Location = New System.Drawing.Point(245, 352)
        Me.txtCommission.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtCommission.Name = "txtCommission"
        Me.txtCommission.Size = New System.Drawing.Size(223, 22)
        Me.txtCommission.TabIndex = 117
        '
        'txtSalaryID
        '
        Me.txtSalaryID.Location = New System.Drawing.Point(245, 253)
        Me.txtSalaryID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtSalaryID.Name = "txtSalaryID"
        Me.txtSalaryID.Size = New System.Drawing.Size(223, 22)
        Me.txtSalaryID.TabIndex = 116
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(245, 95)
        Me.txtName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(223, 22)
        Me.txtName.TabIndex = 115
        '
        'txtStaffID
        '
        Me.txtStaffID.Location = New System.Drawing.Point(245, 59)
        Me.txtStaffID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.Size = New System.Drawing.Size(223, 22)
        Me.txtStaffID.TabIndex = 114
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(65, 413)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 20)
        Me.Label10.TabIndex = 113
        Me.Label10.Text = "Deduction:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(47, 354)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(118, 20)
        Me.Label9.TabIndex = 112
        Me.Label9.Text = "Commission:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(70, 486)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 20)
        Me.Label8.TabIndex = 111
        Me.Label8.Text = "Bank Acc:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(26, 307)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(139, 20)
        Me.Label7.TabIndex = 110
        Me.Label7.Text = "Monthly Salary:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(72, 253)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 20)
        Me.Label6.TabIndex = 109
        Me.Label6.Text = "Salary ID:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(84, 199)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 20)
        Me.Label5.TabIndex = 108
        Me.Label5.Text = "Branch :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(111, 149)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 20)
        Me.Label4.TabIndex = 107
        Me.Label4.Text = "Cvar:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(102, 95)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 106
        Me.Label3.Text = "Name:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(85, 61)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(80, 20)
        Me.label2.TabIndex = 105
        Me.label2.Text = "Staff ID:"
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "payroll"
        Me.BindingSource1.DataSource = Me.PayrollDS
        '
        'PayrollDS
        '
        Me.PayrollDS.DataSetName = "PayrollDS"
        Me.PayrollDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PayrollTableAdapter
        '
        Me.PayrollTableAdapter.ClearBeforeFill = True
        '
        'txtCvar
        '
        Me.txtCvar.FormattingEnabled = True
        Me.txtCvar.Items.AddRange(New Object() {"General Manager", "Manager", "HR Satff", "Supervisor", "Sale assitants"})
        Me.txtCvar.Location = New System.Drawing.Point(245, 145)
        Me.txtCvar.Name = "txtCvar"
        Me.txtCvar.Size = New System.Drawing.Size(223, 24)
        Me.txtCvar.TabIndex = 144
        '
        'txtBramch
        '
        Me.txtBramch.DataSource = Me.BranchBindingSource
        Me.txtBramch.DisplayMember = "Branch name"
        Me.txtBramch.FormattingEnabled = True
        Me.txtBramch.Location = New System.Drawing.Point(245, 195)
        Me.txtBramch.Name = "txtBramch"
        Me.txtBramch.Size = New System.Drawing.Size(223, 24)
        Me.txtBramch.TabIndex = 145
        '
        'BranchBindingSource
        '
        Me.BranchBindingSource.DataMember = "Branch"
        Me.BranchBindingSource.DataSource = Me.BranchDS
        '
        'BranchDS
        '
        Me.BranchDS.DataSetName = "BranchDS"
        Me.BranchDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BranchTableAdapter
        '
        Me.BranchTableAdapter.ClearBeforeFill = True
        '
        'PayrollViewfrmupdate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(778, 562)
        Me.Controls.Add(Me.txtBramch)
        Me.Controls.Add(Me.txtCvar)
        Me.Controls.Add(Me.btmUpdateRecord)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtMonthlySalary)
        Me.Controls.Add(Me.txtBankAcc)
        Me.Controls.Add(Me.txtDeduction)
        Me.Controls.Add(Me.txtCommission)
        Me.Controls.Add(Me.txtSalaryID)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtStaffID)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.label2)
        Me.Name = "PayrollViewfrmupdate"
        Me.Text = "PayrollViewfrmupdate"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PayrollDS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btmUpdateRecord As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtMonthlySalary As TextBox
    Friend WithEvents txtBankAcc As TextBox
    Friend WithEvents txtDeduction As TextBox
    Friend WithEvents txtCommission As TextBox
    Friend WithEvents txtSalaryID As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtStaffID As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents label2 As Label
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents PayrollDS As PayrollDS
    Friend WithEvents PayrollTableAdapter As PayrollDSTableAdapters.payrollTableAdapter
    Friend WithEvents txtCvar As ComboBox
    Friend WithEvents txtBramch As ComboBox
    Friend WithEvents BranchDS As BranchDS
    Friend WithEvents BranchBindingSource As BindingSource
    Friend WithEvents BranchTableAdapter As BranchDSTableAdapters.BranchTableAdapter
End Class
