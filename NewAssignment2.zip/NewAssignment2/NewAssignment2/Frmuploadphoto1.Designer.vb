﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frmuploadphoto1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picShowPicture = New System.Windows.Forms.PictureBox()
        Me.btnSavephoto = New System.Windows.Forms.Button()
        Me.btnupLoad = New System.Windows.Forms.Button()
        Me.lblcID = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ofdPhoto = New System.Windows.Forms.OpenFileDialog()
        Me.sfdPhoto = New System.Windows.Forms.SaveFileDialog()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.picShowPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picShowPicture
        '
        Me.picShowPicture.Location = New System.Drawing.Point(36, 191)
        Me.picShowPicture.Margin = New System.Windows.Forms.Padding(4)
        Me.picShowPicture.Name = "picShowPicture"
        Me.picShowPicture.Size = New System.Drawing.Size(196, 268)
        Me.picShowPicture.TabIndex = 11
        Me.picShowPicture.TabStop = False
        '
        'btnSavephoto
        '
        Me.btnSavephoto.Location = New System.Drawing.Point(409, 266)
        Me.btnSavephoto.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSavephoto.Name = "btnSavephoto"
        Me.btnSavephoto.Size = New System.Drawing.Size(133, 28)
        Me.btnSavephoto.TabIndex = 10
        Me.btnSavephoto.Text = "Save Photo"
        Me.btnSavephoto.UseVisualStyleBackColor = True
        '
        'btnupLoad
        '
        Me.btnupLoad.Location = New System.Drawing.Point(409, 191)
        Me.btnupLoad.Margin = New System.Windows.Forms.Padding(4)
        Me.btnupLoad.Name = "btnupLoad"
        Me.btnupLoad.Size = New System.Drawing.Size(133, 28)
        Me.btnupLoad.TabIndex = 9
        Me.btnupLoad.Text = "Select Photo"
        Me.btnupLoad.UseVisualStyleBackColor = True
        '
        'lblcID
        '
        Me.lblcID.AutoSize = True
        Me.lblcID.Location = New System.Drawing.Point(237, 151)
        Me.lblcID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblcID.Name = "lblcID"
        Me.lblcID.Size = New System.Drawing.Size(51, 17)
        Me.lblcID.TabIndex = 8
        Me.lblcID.Text = "Label3"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(31, 143)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 25)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Employee ID:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(148, 50)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(169, 25)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Employee Photo"
        '
        'ofdPhoto
        '
        Me.ofdPhoto.FileName = "OpenFileDialog1"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(426, 467)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(133, 28)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Frmuploadphoto1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(572, 508)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.picShowPicture)
        Me.Controls.Add(Me.btnSavephoto)
        Me.Controls.Add(Me.btnupLoad)
        Me.Controls.Add(Me.lblcID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Frmuploadphoto1"
        Me.Text = "Employee photo"
        CType(Me.picShowPicture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picShowPicture As PictureBox
    Friend WithEvents btnSavephoto As Button
    Friend WithEvents btnupLoad As Button
    Friend WithEvents lblcID As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ofdPhoto As OpenFileDialog
    Friend WithEvents sfdPhoto As SaveFileDialog
    Friend WithEvents btnExit As Button
End Class
