﻿Public Class adminPayrollViewfrm
    Private Sub adminPayrollViewfrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PayrollDS.payroll' table. You can move, or remove it, as needed.
        Me.PayrollTableAdapter.Fill(Me.PayrollDS.payroll)

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class