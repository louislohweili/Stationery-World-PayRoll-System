﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminMainFrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnPayrollData = New System.Windows.Forms.Button()
        Me.btnEmployeeData = New System.Windows.Forms.Button()
        Me.BtnBranchData = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnPayrollData
        '
        Me.btnPayrollData.Location = New System.Drawing.Point(357, 129)
        Me.btnPayrollData.Name = "btnPayrollData"
        Me.btnPayrollData.Size = New System.Drawing.Size(111, 43)
        Me.btnPayrollData.TabIndex = 34
        Me.btnPayrollData.Text = "Payroll Data"
        Me.btnPayrollData.UseVisualStyleBackColor = True
        '
        'btnEmployeeData
        '
        Me.btnEmployeeData.Location = New System.Drawing.Point(205, 129)
        Me.btnEmployeeData.Name = "btnEmployeeData"
        Me.btnEmployeeData.Size = New System.Drawing.Size(111, 43)
        Me.btnEmployeeData.TabIndex = 33
        Me.btnEmployeeData.Text = "Employee Data"
        Me.btnEmployeeData.UseVisualStyleBackColor = True
        '
        'BtnBranchData
        '
        Me.BtnBranchData.Location = New System.Drawing.Point(61, 129)
        Me.BtnBranchData.Name = "BtnBranchData"
        Me.BtnBranchData.Size = New System.Drawing.Size(111, 43)
        Me.BtnBranchData.TabIndex = 32
        Me.BtnBranchData.Text = "Branch Data"
        Me.BtnBranchData.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(44, 65)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(449, 25)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Welcome to Stationery World Payroll System "
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(403, 247)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(136, 28)
        Me.btnExit.TabIndex = 155
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'AdminMainFrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(552, 288)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnPayrollData)
        Me.Controls.Add(Me.btnEmployeeData)
        Me.Controls.Add(Me.BtnBranchData)
        Me.Controls.Add(Me.Label1)
        Me.Name = "AdminMainFrm"
        Me.Text = "Admin Main"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnPayrollData As Button
    Friend WithEvents btnEmployeeData As Button
    Friend WithEvents BtnBranchData As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnExit As Button
End Class
