﻿Public Class MangePayrollform
    Public StrStaffID As String
    Public StrName As String
    Public StrBramch As String
    Public StrCvar As String
    Public StrSalaryID As String
    Public decMonthlySalary As Double
    Public decCommission As Double
    Public decDeduction As Decimal
    Public strBankAcc As String
    Public dblTotalSalaryMonthly As Double
    Private intRowPosition As Integer = 0

    Private Sub MangePayrollform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PayrollDS2.payroll' table. You can move, or remove it, as needed.
        Me.PayrollTableAdapter.Fill(Me.PayrollDS2.payroll)
        ShowCurrentRecord()
    End Sub

    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            txtStaffID.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("Salary_ID").ToString()
            txtName.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("Name").ToString()
            txtCvar.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("Cvar").ToString()
            txtBramch.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("Branch").ToString()
            txtSalaryID.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("Salary_ID").ToString()
            txtMonthlySalary.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("monthly Salary")
            txtCommission.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("commission")
            txtDeduction.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("deduction")
            txtBankAcc.Text = PayrollDS2.Tables("Payroll").Rows(intRowPosition)("Bank_Acc").ToString()
            StrStaffID = txtStaffID.Text
            StrName = txtName.Text
            StrCvar = txtCvar.Text
            StrBramch = txtBramch.Text
            StrSalaryID = txtSalaryID.Text
            decMonthlySalary = txtMonthlySalary.Text
            decCommission = txtCommission.Text
            decDeduction = txtDeduction.Text

            dblTotalSalaryMonthly = decMonthlySalary + decCommission - decDeduction
            txtTotalSalaryMonthly.Text = dblTotalSalaryMonthly
        End If
    End Sub

    Private Sub btnMoveFirst_Click(sender As Object, e As EventArgs) Handles btnMoveFirst.Click
        intRowPosition = 0
        ShowCurrentRecord()
    End Sub

    Private Sub btnMoveLast_Click(sender As Object, e As EventArgs) Handles btnMoveLast.Click
        If PayrollDS2.Tables("Payroll").Rows.Count > 0 Then
            intRowPosition = PayrollDS2.Tables("Payroll").Rows.Count - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMovePrevious_Click(sender As Object, e As EventArgs) Handles btnMovePrevious.Click
        If intRowPosition > 0 Then
            intRowPosition = intRowPosition - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMoveNext_Click(sender As Object, e As EventArgs) Handles btnMoveNext.Click
        If intRowPosition < (PayrollDS2.Tables("Payroll").Rows.Count - 1) Then
            intRowPosition = intRowPosition + 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnRefreshDat_Click(sender As Object, e As EventArgs) Handles btnRefreshDat.Click
        Me.PayrollTableAdapter.Fill(Me.PayrollDS2.payroll)
        ShowCurrentRecord()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub btmUpdateRecord_Click(sender As Object, e As EventArgs) Handles btmUpdateRecord.Click
        If PayrollDS2.Tables("payroll").Rows.Count <> 0 Then
            Try
                PayrollDS2.Tables("payroll").Rows(intRowPosition)("Staff_ID") = txtStaffID.Text
                PayrollDS2.Tables("payroll").Rows(intRowPosition)("Name") = txtName.Text
                PayrollDS2.Tables("payroll").Rows(intRowPosition)("Cvar") = txtCvar.Text
                PayrollDS2.Tables("payroll").Rows(intRowPosition)("Branch") = txtBramch.Text
                PayrollDS2.Tables("payroll").Rows(intRowPosition)("Salary_ID") = txtSalaryID.Text
                PayrollDS2.Tables("payroll").Rows(intRowPosition)("commission") = txtCommission.Text
                PayrollDS2.Tables("payroll").Rows(intRowPosition)("deduction") = txtDeduction.Text
                PayrollDS2.Tables("payroll").Rows(intRowPosition)("Bank_Acc") = txtBankAcc.Text
                PayrollTableAdapter.Update(PayrollDS2.payroll)
                PayrollDS2.AcceptChanges()
                MessageBox.Show("Record Update")
                Me.PayrollTableAdapter.Fill(PayrollDS2.payroll)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try


        End If
    End Sub


    Private Sub btnDeleteRecord_Click(sender As Object, e As EventArgs) Handles btnDeleteRecord.Click
        If PayrollDS2.Tables("Payroll").Rows.Count <> 0 Then
            PayrollDS2.Tables("Payroll").Rows(intRowPosition).Delete()
            intRowPosition = intRowPosition - 1
            PayrollTableAdapter.Update(Me.PayrollDS2.payroll)
            MessageBox.Show("Record delete")
            Me.PayrollTableAdapter.Update(Me.PayrollDS2.payroll)
            ShowCurrentRecord()

        End If
    End Sub

    Private Sub btnNewRecord_Click(sender As Object, e As EventArgs) Handles btnNewRecord.Click
        PayrollViewfrmupdate.ShowDialog()
    End Sub

    Private Sub btnExit_Click_1(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class