﻿Public Class MangaeEmployeeForm
    Private intRowPosition As Integer = 0
    Private Sub MangaeEmployeeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EmployeeDS.Employee' table. You can move, or remove it, as needed.
        Me.EmployeeTableAdapter.Fill(Me.EmployeeDS.Employee)
        ShowCurrentRecord()
    End Sub
    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            txtStaffID.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Staff_ID").ToString()
            txtName.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Name").ToString()
            txtDOB.Text = Format(EmployeeDS.Tables("Employee").Rows(intRowPosition)("DOB"), "dd-MM-yyyy")
            txtGender.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Gender").ToString()
            txtEmail.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Email").ToString()
            txtHireDate.Text = Format(EmployeeDS.Tables("Employee").Rows(intRowPosition)("Hire_date"), "dd-MM-yyyy")
            txtCvar.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Cvar").ToString()
            txtBranch.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Branch").ToString()
            txtBranchNo.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Branch_no").ToString()
            txtSalary.Text = EmployeeDS.Tables("Employee").Rows(intRowPosition)("Salary").ToString()
        End If
    End Sub

    Private Sub btnMoveFirst_Click(sender As Object, e As EventArgs) Handles btnMoveFirst.Click
        intRowPosition = 0
        ShowCurrentRecord()
    End Sub

    Private Sub btnMoveLast_Click(sender As Object, e As EventArgs) Handles btnMoveLast.Click
        If EmployeeDS.Tables("Employee").Rows.Count > 0 Then
            intRowPosition = EmployeeDS.Tables("Employee").Rows.Count - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMovePrevious_Click(sender As Object, e As EventArgs) Handles btnMovePrevious.Click
        If intRowPosition > 0 Then
            intRowPosition = intRowPosition - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMoveNext_Click(sender As Object, e As EventArgs) Handles btnMoveNext.Click
        If intRowPosition < (EmployeeDS.Tables("Employee").Rows.Count - 1) Then
            intRowPosition = intRowPosition + 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnRefreshDat_Click(sender As Object, e As EventArgs) Handles btnRefreshDat.Click
        Me.EmployeeTableAdapter.Fill(Me.EmployeeDS.Employee)
        ShowCurrentRecord()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) 
        Me.Close()
    End Sub

    Private Sub btmUpdateRecord_Click(sender As Object, e As EventArgs) Handles btmUpdateRecord.Click
        If EmployeeDS.Tables("Employee").Rows.Count <> 0 Then
            Try
                EmployeeDS.Tables("Employee").Rows(intRowPosition)("Staff_ID") = txtStaffID.Text
                EmployeeDS.Tables("Employee").Rows(intRowPosition)("Name") = txtName.Text
                EmployeeDS.Tables("Employee").Rows(intRowPosition)("Email") = txtEmail.Text
                EmployeeDS.Tables("Employee").Rows(intRowPosition)("Cvar") = txtCvar.Text
                EmployeeDS.Tables("Employee").Rows(intRowPosition)("Branch") = txtBranch.Text
                EmployeeDS.Tables("Employee").Rows(intRowPosition)("Branch_no") = txtBranchNo.Text
                EmployeeDS.Tables("Employee").Rows(intRowPosition)("Salary") = txtSalary.Text
                EmployeeTableAdapter.Update(Me.EmployeeDS.Employee)
                EmployeeDS.AcceptChanges()
            Catch ex As Exception
                MessageBox.Show("Record Update")
                Me.EmployeeTableAdapter.Fill(Me.EmployeeDS.Employee)
            End Try
        End If
    End Sub
    Private Sub btnDeleteRecord_Click(sender As Object, e As EventArgs) Handles btnDeleteRecord.Click
        If EmployeeDS.Tables("Employee").Rows.Count <> 0 Then
            EmployeeDS.Tables("Employee").Rows(intRowPosition).Delete()
            intRowPosition = intRowPosition - 1
            EmployeeTableAdapter.Update(Me.EmployeeDS.Employee)
            MessageBox.Show("Record delete")
            Me.EmployeeTableAdapter.Update(Me.EmployeeDS.Employee)
            ShowCurrentRecord()

        End If
    End Sub

    Private Sub btnNewRecord_Click(sender As Object, e As EventArgs) Handles btnNewRecord.Click
        EmployeeviewFormUpdate.ShowDialog()
    End Sub

    Private Sub btnExit_Click_1(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class