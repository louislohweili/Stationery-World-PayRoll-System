﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MangaeBranchForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnDeleteRecord = New System.Windows.Forms.Button()
        Me.btmUpdateRecord = New System.Windows.Forms.Button()
        Me.btnNewRecord = New System.Windows.Forms.Button()
        Me.btnRefreshDat = New System.Windows.Forms.Button()
        Me.txtBranchData = New System.Windows.Forms.TextBox()
        Me.txtMangeInChange = New System.Windows.Forms.TextBox()
        Me.txtBranchContactNo = New System.Windows.Forms.TextBox()
        Me.txtBranchAddress = New System.Windows.Forms.TextBox()
        Me.txtBranchName = New System.Windows.Forms.TextBox()
        Me.txtBranchID = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchDS = New NewAssignment2.BranchDS()
        Me.btnMoveNext = New System.Windows.Forms.Button()
        Me.btnMovePrevious = New System.Windows.Forms.Button()
        Me.btnMoveLast = New System.Windows.Forms.Button()
        Me.btnMoveFirst = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.BranchTableAdapter = New NewAssignment2.BranchDSTableAdapters.BranchTableAdapter()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDeleteRecord
        '
        Me.btnDeleteRecord.Location = New System.Drawing.Point(646, 154)
        Me.btnDeleteRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDeleteRecord.Name = "btnDeleteRecord"
        Me.btnDeleteRecord.Size = New System.Drawing.Size(136, 28)
        Me.btnDeleteRecord.TabIndex = 97
        Me.btnDeleteRecord.Text = "Delete Record"
        Me.btnDeleteRecord.UseVisualStyleBackColor = True
        '
        'btmUpdateRecord
        '
        Me.btmUpdateRecord.Location = New System.Drawing.Point(646, 83)
        Me.btmUpdateRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btmUpdateRecord.Name = "btmUpdateRecord"
        Me.btmUpdateRecord.Size = New System.Drawing.Size(136, 28)
        Me.btmUpdateRecord.TabIndex = 96
        Me.btmUpdateRecord.Text = "Update Record"
        Me.btmUpdateRecord.UseVisualStyleBackColor = True
        '
        'btnNewRecord
        '
        Me.btnNewRecord.Location = New System.Drawing.Point(646, 219)
        Me.btnNewRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btnNewRecord.Name = "btnNewRecord"
        Me.btnNewRecord.Size = New System.Drawing.Size(136, 28)
        Me.btnNewRecord.TabIndex = 95
        Me.btnNewRecord.Text = "New Record"
        Me.btnNewRecord.UseVisualStyleBackColor = True
        '
        'btnRefreshDat
        '
        Me.btnRefreshDat.Location = New System.Drawing.Point(646, 299)
        Me.btnRefreshDat.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRefreshDat.Name = "btnRefreshDat"
        Me.btnRefreshDat.Size = New System.Drawing.Size(136, 28)
        Me.btnRefreshDat.TabIndex = 94
        Me.btnRefreshDat.Text = "Refresh Data"
        Me.btnRefreshDat.UseVisualStyleBackColor = True
        '
        'txtBranchData
        '
        Me.txtBranchData.Location = New System.Drawing.Point(215, 424)
        Me.txtBranchData.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchData.Name = "txtBranchData"
        Me.txtBranchData.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchData.TabIndex = 92
        '
        'txtMangeInChange
        '
        Me.txtMangeInChange.Location = New System.Drawing.Point(215, 336)
        Me.txtMangeInChange.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtMangeInChange.Name = "txtMangeInChange"
        Me.txtMangeInChange.Size = New System.Drawing.Size(223, 22)
        Me.txtMangeInChange.TabIndex = 91
        '
        'txtBranchContactNo
        '
        Me.txtBranchContactNo.Location = New System.Drawing.Point(215, 252)
        Me.txtBranchContactNo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchContactNo.Name = "txtBranchContactNo"
        Me.txtBranchContactNo.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchContactNo.TabIndex = 90
        '
        'txtBranchAddress
        '
        Me.txtBranchAddress.Location = New System.Drawing.Point(215, 203)
        Me.txtBranchAddress.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchAddress.Name = "txtBranchAddress"
        Me.txtBranchAddress.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchAddress.TabIndex = 89
        '
        'txtBranchName
        '
        Me.txtBranchName.Location = New System.Drawing.Point(215, 136)
        Me.txtBranchName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchName.Name = "txtBranchName"
        Me.txtBranchName.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchName.TabIndex = 88
        '
        'txtBranchID
        '
        Me.txtBranchID.Location = New System.Drawing.Point(215, 83)
        Me.txtBranchID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchID.Name = "txtBranchID"
        Me.txtBranchID.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchID.TabIndex = 87
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(86, 426)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(123, 20)
        Me.Label7.TabIndex = 86
        Me.Label7.Text = "Branch data :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(35, 327)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(174, 20)
        Me.Label6.TabIndex = 85
        Me.Label6.Text = "Manage in-change :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(41, 252)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(169, 20)
        Me.Label5.TabIndex = 84
        Me.Label5.Text = "Branch contact no:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(49, 205)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 20)
        Me.Label4.TabIndex = 83
        Me.Label4.Text = "Branch address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(71, 136)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(126, 20)
        Me.Label3.TabIndex = 82
        Me.Label3.Text = "Branch name:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(82, 83)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(100, 20)
        Me.label2.TabIndex = 81
        Me.label2.Text = "Branch ID:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(101, 10)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(449, 25)
        Me.Label1.TabIndex = 79
        Me.Label1.Text = "Welcome to Stationery World Payroll System "
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "Branch"
        Me.BindingSource1.DataSource = Me.BranchDS
        '
        'BranchDS
        '
        Me.BranchDS.DataSetName = "BranchDS"
        Me.BranchDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnMoveNext
        '
        Me.btnMoveNext.Location = New System.Drawing.Point(647, 502)
        Me.btnMoveNext.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnMoveNext.Name = "btnMoveNext"
        Me.btnMoveNext.Size = New System.Drawing.Size(76, 39)
        Me.btnMoveNext.TabIndex = 123
        Me.btnMoveNext.Text = ">>"
        Me.btnMoveNext.UseVisualStyleBackColor = True
        '
        'btnMovePrevious
        '
        Me.btnMovePrevious.Location = New System.Drawing.Point(451, 502)
        Me.btnMovePrevious.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnMovePrevious.Name = "btnMovePrevious"
        Me.btnMovePrevious.Size = New System.Drawing.Size(99, 39)
        Me.btnMovePrevious.TabIndex = 122
        Me.btnMovePrevious.Text = ">"
        Me.btnMovePrevious.UseVisualStyleBackColor = True
        '
        'btnMoveLast
        '
        Me.btnMoveLast.Location = New System.Drawing.Point(279, 502)
        Me.btnMoveLast.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnMoveLast.Name = "btnMoveLast"
        Me.btnMoveLast.Size = New System.Drawing.Size(88, 39)
        Me.btnMoveLast.TabIndex = 121
        Me.btnMoveLast.Text = "<"
        Me.btnMoveLast.UseVisualStyleBackColor = True
        '
        'btnMoveFirst
        '
        Me.btnMoveFirst.Location = New System.Drawing.Point(47, 502)
        Me.btnMoveFirst.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnMoveFirst.Name = "btnMoveFirst"
        Me.btnMoveFirst.Size = New System.Drawing.Size(104, 39)
        Me.btnMoveFirst.TabIndex = 120
        Me.btnMoveFirst.Text = "<<"
        Me.btnMoveFirst.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(646, 379)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(136, 28)
        Me.btnExit.TabIndex = 155
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'BranchTableAdapter
        '
        Me.BranchTableAdapter.ClearBeforeFill = True
        '
        'MangaeBranchForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(824, 566)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnMoveNext)
        Me.Controls.Add(Me.btnMovePrevious)
        Me.Controls.Add(Me.btnMoveLast)
        Me.Controls.Add(Me.btnMoveFirst)
        Me.Controls.Add(Me.btnDeleteRecord)
        Me.Controls.Add(Me.btmUpdateRecord)
        Me.Controls.Add(Me.btnNewRecord)
        Me.Controls.Add(Me.btnRefreshDat)
        Me.Controls.Add(Me.txtBranchData)
        Me.Controls.Add(Me.txtMangeInChange)
        Me.Controls.Add(Me.txtBranchContactNo)
        Me.Controls.Add(Me.txtBranchAddress)
        Me.Controls.Add(Me.txtBranchName)
        Me.Controls.Add(Me.txtBranchID)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "MangaeBranchForm"
        Me.Text = "MangaeBranchForm"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnDeleteRecord As Button
    Friend WithEvents btmUpdateRecord As Button
    Friend WithEvents btnNewRecord As Button
    Friend WithEvents btnRefreshDat As Button
    Friend WithEvents txtBranchData As TextBox
    Friend WithEvents txtMangeInChange As TextBox
    Friend WithEvents txtBranchContactNo As TextBox
    Friend WithEvents txtBranchAddress As TextBox
    Friend WithEvents txtBranchName As TextBox
    Friend WithEvents txtBranchID As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents btnMoveNext As Button
    Friend WithEvents btnMovePrevious As Button
    Friend WithEvents btnMoveLast As Button
    Friend WithEvents btnMoveFirst As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents BranchDS As BranchDS
    Friend WithEvents BranchTableAdapter As BranchDSTableAdapters.BranchTableAdapter
End Class
