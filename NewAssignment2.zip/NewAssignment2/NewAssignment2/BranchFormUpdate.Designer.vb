﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BranchFormUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btmUpdateRecord = New System.Windows.Forms.Button()
        Me.txtBranchData = New System.Windows.Forms.TextBox()
        Me.txtMangeInChange = New System.Windows.Forms.TextBox()
        Me.txtBranchContactNo = New System.Windows.Forms.TextBox()
        Me.txtBranchAddress = New System.Windows.Forms.TextBox()
        Me.txtBranchName = New System.Windows.Forms.TextBox()
        Me.txtBranchID = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchDS = New NewAssignment2.BranchDS()
        Me.BranchTableAdapter = New NewAssignment2.BranchDSTableAdapters.BranchTableAdapter()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(523, 512)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(99, 39)
        Me.btnClear.TabIndex = 109
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btmUpdateRecord
        '
        Me.btmUpdateRecord.Location = New System.Drawing.Point(598, 102)
        Me.btmUpdateRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btmUpdateRecord.Name = "btmUpdateRecord"
        Me.btmUpdateRecord.Size = New System.Drawing.Size(136, 28)
        Me.btmUpdateRecord.TabIndex = 108
        Me.btmUpdateRecord.Text = "Update Record"
        Me.btmUpdateRecord.UseVisualStyleBackColor = True
        '
        'txtBranchData
        '
        Me.txtBranchData.Location = New System.Drawing.Point(229, 446)
        Me.txtBranchData.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchData.Name = "txtBranchData"
        Me.txtBranchData.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchData.TabIndex = 107
        '
        'txtMangeInChange
        '
        Me.txtMangeInChange.Location = New System.Drawing.Point(229, 358)
        Me.txtMangeInChange.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtMangeInChange.Name = "txtMangeInChange"
        Me.txtMangeInChange.Size = New System.Drawing.Size(223, 22)
        Me.txtMangeInChange.TabIndex = 106
        '
        'txtBranchContactNo
        '
        Me.txtBranchContactNo.Location = New System.Drawing.Point(229, 274)
        Me.txtBranchContactNo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchContactNo.Name = "txtBranchContactNo"
        Me.txtBranchContactNo.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchContactNo.TabIndex = 105
        '
        'txtBranchAddress
        '
        Me.txtBranchAddress.Location = New System.Drawing.Point(229, 225)
        Me.txtBranchAddress.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchAddress.Name = "txtBranchAddress"
        Me.txtBranchAddress.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchAddress.TabIndex = 104
        '
        'txtBranchName
        '
        Me.txtBranchName.Location = New System.Drawing.Point(229, 158)
        Me.txtBranchName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchName.Name = "txtBranchName"
        Me.txtBranchName.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchName.TabIndex = 103
        '
        'txtBranchID
        '
        Me.txtBranchID.Location = New System.Drawing.Point(229, 102)
        Me.txtBranchID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBranchID.Name = "txtBranchID"
        Me.txtBranchID.Size = New System.Drawing.Size(223, 22)
        Me.txtBranchID.TabIndex = 102
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(100, 448)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(123, 20)
        Me.Label7.TabIndex = 101
        Me.Label7.Text = "Branch data :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(49, 349)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(174, 20)
        Me.Label6.TabIndex = 100
        Me.Label6.Text = "Manage in-change :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(55, 274)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(169, 20)
        Me.Label5.TabIndex = 99
        Me.Label5.Text = "Branch contact no:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(63, 227)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 20)
        Me.Label4.TabIndex = 98
        Me.Label4.Text = "Branch address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(85, 158)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(126, 20)
        Me.Label3.TabIndex = 97
        Me.Label3.Text = "Branch name:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(96, 105)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(100, 20)
        Me.label2.TabIndex = 96
        Me.label2.Text = "Branch ID:"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(667, 512)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(99, 39)
        Me.btnExit.TabIndex = 95
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(115, 32)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(449, 25)
        Me.Label1.TabIndex = 94
        Me.Label1.Text = "Welcome to Stationery World Payroll System "
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "Branch"
        Me.BindingSource1.DataSource = Me.BranchDS
        '
        'BranchDS
        '
        Me.BranchDS.DataSetName = "BranchDS"
        Me.BranchDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BranchTableAdapter
        '
        Me.BranchTableAdapter.ClearBeforeFill = True
        '
        'BranchFormUpdate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(787, 582)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btmUpdateRecord)
        Me.Controls.Add(Me.txtBranchData)
        Me.Controls.Add(Me.txtMangeInChange)
        Me.Controls.Add(Me.txtBranchContactNo)
        Me.Controls.Add(Me.txtBranchAddress)
        Me.Controls.Add(Me.txtBranchName)
        Me.Controls.Add(Me.txtBranchID)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label1)
        Me.Name = "BranchFormUpdate"
        Me.Text = "BranchFormUpdate"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnClear As Button
    Friend WithEvents btmUpdateRecord As Button
    Friend WithEvents txtBranchData As TextBox
    Friend WithEvents txtMangeInChange As TextBox
    Friend WithEvents txtBranchContactNo As TextBox
    Friend WithEvents txtBranchAddress As TextBox
    Friend WithEvents txtBranchName As TextBox
    Friend WithEvents txtBranchID As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents label2 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents BranchDS As BranchDS
    Friend WithEvents BranchTableAdapter As BranchDSTableAdapters.BranchTableAdapter
End Class
