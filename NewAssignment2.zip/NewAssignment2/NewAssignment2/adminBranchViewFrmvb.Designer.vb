﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class adminBranchViewFrmvb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.BranchDS = New NewAssignment2.BranchDS()
        Me.BranchDSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BranchTableAdapter = New NewAssignment2.BranchDSTableAdapters.BranchTableAdapter()
        Me.BranchIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BranchNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BranchAddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BranchContactNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ManageinchangeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BranchDataDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchDSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BranchBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BranchIDDataGridViewTextBoxColumn, Me.BranchNameDataGridViewTextBoxColumn, Me.BranchAddressDataGridViewTextBoxColumn, Me.BranchContactNoDataGridViewTextBoxColumn, Me.ManageinchangeDataGridViewTextBoxColumn, Me.BranchDataDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.BranchBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(-2, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(659, 150)
        Me.DataGridView1.TabIndex = 0
        '
        'BranchDS
        '
        Me.BranchDS.DataSetName = "BranchDS"
        Me.BranchDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BranchDSBindingSource
        '
        Me.BranchDSBindingSource.DataSource = Me.BranchDS
        Me.BranchDSBindingSource.Position = 0
        '
        'BranchBindingSource
        '
        Me.BranchBindingSource.DataMember = "Branch"
        Me.BranchBindingSource.DataSource = Me.BranchDSBindingSource
        '
        'BranchTableAdapter
        '
        Me.BranchTableAdapter.ClearBeforeFill = True
        '
        'BranchIDDataGridViewTextBoxColumn
        '
        Me.BranchIDDataGridViewTextBoxColumn.DataPropertyName = "Branch_ID"
        Me.BranchIDDataGridViewTextBoxColumn.HeaderText = "Branch_ID"
        Me.BranchIDDataGridViewTextBoxColumn.Name = "BranchIDDataGridViewTextBoxColumn"
        '
        'BranchNameDataGridViewTextBoxColumn
        '
        Me.BranchNameDataGridViewTextBoxColumn.DataPropertyName = "Branch name"
        Me.BranchNameDataGridViewTextBoxColumn.HeaderText = "Branch name"
        Me.BranchNameDataGridViewTextBoxColumn.Name = "BranchNameDataGridViewTextBoxColumn"
        '
        'BranchAddressDataGridViewTextBoxColumn
        '
        Me.BranchAddressDataGridViewTextBoxColumn.DataPropertyName = "Branch address"
        Me.BranchAddressDataGridViewTextBoxColumn.HeaderText = "Branch address"
        Me.BranchAddressDataGridViewTextBoxColumn.Name = "BranchAddressDataGridViewTextBoxColumn"
        '
        'BranchContactNoDataGridViewTextBoxColumn
        '
        Me.BranchContactNoDataGridViewTextBoxColumn.DataPropertyName = "Branch contact no"
        Me.BranchContactNoDataGridViewTextBoxColumn.HeaderText = "Branch contact no"
        Me.BranchContactNoDataGridViewTextBoxColumn.Name = "BranchContactNoDataGridViewTextBoxColumn"
        '
        'ManageinchangeDataGridViewTextBoxColumn
        '
        Me.ManageinchangeDataGridViewTextBoxColumn.DataPropertyName = "Manage-in-change"
        Me.ManageinchangeDataGridViewTextBoxColumn.HeaderText = "Manage-in-change"
        Me.ManageinchangeDataGridViewTextBoxColumn.Name = "ManageinchangeDataGridViewTextBoxColumn"
        '
        'BranchDataDataGridViewTextBoxColumn
        '
        Me.BranchDataDataGridViewTextBoxColumn.DataPropertyName = "Branch data"
        Me.BranchDataDataGridViewTextBoxColumn.HeaderText = "Branch data"
        Me.BranchDataDataGridViewTextBoxColumn.Name = "BranchDataDataGridViewTextBoxColumn"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(511, 437)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(146, 35)
        Me.btnExit.TabIndex = 147
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'adminBranchViewFrmvb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(660, 486)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "adminBranchViewFrmvb"
        Me.Text = "adminBranchViewFrmvb"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchDS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchDSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BranchBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents BranchDSBindingSource As BindingSource
    Friend WithEvents BranchDS As BranchDS
    Friend WithEvents BranchBindingSource As BindingSource
    Friend WithEvents BranchTableAdapter As BranchDSTableAdapters.BranchTableAdapter
    Friend WithEvents BranchIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BranchNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BranchAddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BranchContactNoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ManageinchangeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BranchDataDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents btnExit As Button
End Class
