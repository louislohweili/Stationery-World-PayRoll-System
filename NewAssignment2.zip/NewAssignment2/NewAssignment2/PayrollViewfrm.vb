﻿Public Class PayrollViewfrm
    Public StrStaffID As String
    Public StrName As String
    Public StrBramch As String
    Public StrCvar As String
    Public StrSalaryID As String
    Public decMonthlySalary As Double
    Public decCommission As Double
    Public decDeduction As Decimal
    Public strBankAcc As String
    Public dblTotalSalaryMonthly As Double
    Private intRowPosition As Integer = 0
    Private Sub PayrollViewfrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PayrollDS.payroll' table. You can move, or remove it, as needed.
    End Sub
    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            lblSID.Text = PayrollDS.Tables("Payroll").Rows(intRowPosition)("Staff_ID").ToString()
            lblName.Text = PayrollDS.Tables("Payroll").Rows(intRowPosition)("Name").ToString()
            lblCvar.Text = PayrollDS.Tables("Payroll").Rows(intRowPosition)("Cvar").ToString()
            lblBranch.Text = PayrollDS.Tables("Payroll").Rows(intRowPosition)("Branch").ToString()
            lblSalaryID.Text = PayrollDS.Tables("Payroll").Rows(intRowPosition)("Salary_ID").ToString()
            lblMSalary.Text = FormatCurrency(PayrollDS.Tables("Payroll").Rows(intRowPosition)("monthly Salary"))
            lblCommission.Text = FormatCurrency(PayrollDS.Tables("Payroll").Rows(intRowPosition)("commission"))
            lblDeduction.Text = FormatCurrency(PayrollDS.Tables("Payroll").Rows(intRowPosition)("deduction"))
            lblBAcc.Text = PayrollDS.Tables("Payroll").Rows(intRowPosition)("Bank_Acc").ToString()
            StrStaffID = lblSID.Text
            StrName = lblName.Text
            StrCvar = lblCvar.Text
            StrBramch = lblBranch.Text
            StrSalaryID = lblSalaryID.Text
            decMonthlySalary = lblMSalary.Text
            decCommission = lblCommission.Text
            decDeduction = lblDeduction.Text

            dblTotalSalaryMonthly = decMonthlySalary + decCommission - decDeduction
            lblTotalSalaryMonthly.Text = Format(dblTotalSalaryMonthly, "c2")
        End If
    End Sub
    Private Sub btnMoveFirst_Click(sender As Object, e As EventArgs) Handles btnMoveFirst.Click
        intRowPosition = 0
        ShowCurrentRecord()
    End Sub

    Private Sub btnMoveLast_Click(sender As Object, e As EventArgs) Handles btnMoveLast.Click
        If PayrollDS.Tables("Payroll").Rows.Count > 0 Then
            intRowPosition = PayrollDS.Tables("Payroll").Rows.Count - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMovePrevious_Click(sender As Object, e As EventArgs) Handles btnMovePrevious.Click
        If intRowPosition > 0 Then
            intRowPosition = intRowPosition - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMoveNext_Click(sender As Object, e As EventArgs) Handles btnMoveNext.Click
        If intRowPosition < (PayrollDS.Tables("Payroll").Rows.Count - 1) Then
            intRowPosition = intRowPosition + 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMangeRecord_Click(sender As Object, e As EventArgs) Handles btnMangeRecord.Click
        MangePayrollform.ShowDialog()
    End Sub

    Private Sub btnRefreshDat_Click(sender As Object, e As EventArgs) Handles btnRefreshDat.Click
        Me.PayrollTableAdapter.Fill(Me.PayrollDS.payroll)
        ShowCurrentRecord()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class