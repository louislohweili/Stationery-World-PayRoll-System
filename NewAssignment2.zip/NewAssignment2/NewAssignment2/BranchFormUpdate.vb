﻿Public Class BranchFormUpdate
    Private intRowPosition As Integer = 0
    Private Sub BranchFormUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BranchDS.Branch' table. You can move, or remove it, as needed.
        Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)

    End Sub
    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            txtBranchID.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch_ID").ToString()
            txtBranchName.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch name").ToString()
            txtBranchAddress.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch address").ToString()
            txtBranchContactNo.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch contact no").ToString()
            txtMangeInChange.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Manage-in-change").ToString()
            txtBranchData.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch data").ToString()
        End If
    End Sub

    Private Sub btmUpdateRecord_Click(sender As Object, e As EventArgs) Handles btmUpdateRecord.Click
        Dim newrow As DataRow = BranchDS.Tables("Branch").NewRow
        Try
            newrow("Branch_ID") = txtBranchID.Text
            newrow("Branch name") = txtBranchName.Text
            newrow("Branch address") = txtBranchAddress.Text
            newrow("Branch contact no") = txtBranchContactNo.Text
            newrow("Manage-in-change") = txtMangeInChange.Text
            newrow("Branch data") = txtBranchData.Text

            BranchDS.Tables("Branch").Rows.Add(newrow)
            BranchTableAdapter.Update(Me.BranchDS.Branch)

            BranchDS.AcceptChanges()
            MessageBox.Show("Record Update")
            Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class