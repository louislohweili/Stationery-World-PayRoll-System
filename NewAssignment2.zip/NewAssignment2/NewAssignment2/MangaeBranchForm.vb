﻿Public Class MangaeBranchForm
    Private intRowPosition As Integer = 0
    Private Sub MangaeBranchForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BranchDS.Branch' table. You can move, or remove it, as needed.
        Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)


        ShowCurrentRecord()
    End Sub
    Private Sub ShowCurrentRecord()
        If intRowPosition >= 0 Then
            txtBranchID.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch_ID").ToString()
            txtBranchName.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch name").ToString()
            txtBranchAddress.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch address").ToString()
            txtBranchContactNo.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch contact no").ToString()
            txtMangeInChange.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Manage-in-change").ToString()
            txtBranchData.Text = BranchDS.Tables("Branch").Rows(intRowPosition)("Branch data").ToString()
        End If
    End Sub
    Private Sub btnMoveFirst_Click(sender As Object, e As EventArgs) Handles btnMoveFirst.Click
        intRowPosition = 0
        ShowCurrentRecord()
    End Sub

    Private Sub btnMoveLast_Click(sender As Object, e As EventArgs) Handles btnMoveLast.Click
        If BranchDS.Tables("Branch").Rows.Count > 0 Then
            intRowPosition = BranchDS.Tables("Branch").Rows.Count - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMovePrevious_Click(sender As Object, e As EventArgs)
        If intRowPosition > 0 Then
            intRowPosition = intRowPosition - 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnMoveNext_Click(sender As Object, e As EventArgs)
        If intRowPosition < (BranchDS.Tables("Branch").Rows.Count - 1) Then
            intRowPosition = intRowPosition + 1
            Me.ShowCurrentRecord()
        End If
    End Sub

    Private Sub btnRefreshDat_Click(sender As Object, e As EventArgs) Handles btnRefreshDat.Click
        Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
        ShowCurrentRecord()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub btnDeleteRecord_Click(sender As Object, e As EventArgs) Handles btnDeleteRecord.Click
        If BranchDS.Tables("Branch").Rows.Count <> 0 Then
            BranchDS.Tables("Branch").Rows(intRowPosition).Delete()
            intRowPosition = intRowPosition - 1
            Me.ShowCurrentRecord()

            BranchTableAdapter.Update(Me.BranchDS.Branch)
            MessageBox.Show("Record delete")
            Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
        End If
    End Sub

    Private Sub btnNewRecord_Click(sender As Object, e As EventArgs) Handles btnNewRecord.Click
        BranchFormUpdate.ShowDialog()
    End Sub

    Private Sub btmUpdateRecord_Click(sender As Object, e As EventArgs) Handles btmUpdateRecord.Click
        If BranchDS.Tables("Branch").Rows.Count <> 0 Then
            Try
                BranchDS.Tables("Branch").Rows(intRowPosition)("Branch_ID") = txtBranchID.Text
                BranchDS.Tables("Branch").Rows(intRowPosition)("Branch name") = txtBranchName.Text
                BranchDS.Tables("Branch").Rows(intRowPosition)("Branch address") = txtBranchAddress.Text
                BranchDS.Tables("Branch").Rows(intRowPosition)("Branch contact no") = txtBranchContactNo.Text
                BranchDS.Tables("Branch").Rows(intRowPosition)("Manage-in-change") = txtMangeInChange.Text
                BranchDS.Tables("Branch").Rows(intRowPosition)("Branch data") = txtBranchData.Text
                BranchTableAdapter.Update(Me.BranchDS.Branch)
                BranchDS.AcceptChanges()
                MessageBox.Show("Record Update")
            Catch ex As Exception
                Me.BranchTableAdapter.Fill(Me.BranchDS.Branch)
            End Try
        End If

    End Sub

    Private Sub btnExit_Click_1(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class